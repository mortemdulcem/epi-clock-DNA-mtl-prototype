"""
EpiClock Prototype - DNA Methylation Epigenetic Age Analysis Platform
DNA Metilasyon Tabanlı Epigenetik Yaş İvmelenmesi Analiz Platformu

A comprehensive PROTOTYPE platform for detecting and quantifying epigenetic age acceleration 
in addiction using DNA methylation clocks.

IMPORTANT DISCLAIMER:
This is a PROTOTYPE/DEMONSTRATION platform that uses SIMULATED DATA to demonstrate
the analytical workflow and methodology. The epigenetic clock coefficients and reference
database are simulated based on published research statistics, not the actual coefficients.

For research or clinical use:
- The actual Horvath/Hannum/PhenoAge/GrimAge/DunedinPACE coefficients are available in
  their respective publications' supplementary materials and must be obtained through
  proper academic channels.
- The reference database is simulated; actual methylation profiles require data access
  agreements from repositories like GEO.

This platform demonstrates the complete analytical architecture and can integrate
real coefficients and data when obtained through proper licensing channels.
"""

import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import io
import base64

from modules.epigenetic_clocks import EpigeneticClockCalculator, ClockResult
from modules.ml_models import EnsembleAgePredictor, generate_synthetic_training_data
from modules.data_processing import MethylationDataProcessor
from modules.statistics import StatisticalAnalyzer
from modules.visualization import EpigeneticVisualizer
from modules.reference_database import ReferenceDatabase
from modules.report_generator import ReportGenerator
from modules.database import DatabaseManager
from modules.longitudinal import LongitudinalAnalyzer
from modules.gsea import GSEAnalyzer
from modules.clinical_decision import ClinicalDecisionSupport
from modules.multiomics import MultiOmicsIntegrator
from modules.postmortem import PostmortemValidator, ForensicApplications
from modules.moderation import (
    EmotionRegulationModerator, 
    SelfControlModerator, 
    ReversibilityAnalysis, 
    ClinicalCovariates
)
from modules.tissue_clocks import (
    TissueType,
    TissueSpecificClockCalculator,
    CrossTissueNormalizer,
    TissueAgeDiscordanceAnalyzer,
    get_tissue_clock_summary
)
from modules.audit import (
    BlockchainAuditLedger,
    ForensicChainOfCustody,
    TamperDetectionSimulator,
    AuditAction,
    get_audit_summary_table
)
from modules.mobile_ui import (
    inject_responsive_css,
    WizardWorkflow,
    WizardStep,
    RoleBasedUI,
    UserRole,
    render_touch_friendly_tabs,
    create_quick_action_buttons,
    render_mobile_summary_cards,
    init_mobile_ui
)

st.set_page_config(
    page_title="EpiClock Prototype - Epigenetik Yaş Analizi",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;500;700&family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Dark Theme Base */
    .stApp {
        background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #0f0f23 100%) !important;
    }
    
    .main .block-container {
        background: transparent !important;
        padding-top: 2rem;
    }
    
    /* Sidebar Dark Theme */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0d0d0d 0%, #1a1a2e 100%) !important;
        border-right: 1px solid #00ff4120;
    }
    
    [data-testid="stSidebar"] * {
        color: #e0e0e0 !important;
    }
    
    /* DNA Helix Animation Container */
    .dna-container {
        position: relative;
        width: 100%;
        height: 200px;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 1rem;
        overflow: hidden;
    }
    
    .dna-helix {
        position: relative;
        width: 300px;
        height: 180px;
    }
    
    .dna-strand {
        position: absolute;
        width: 100%;
        height: 100%;
    }
    
    .nucleotide {
        position: absolute;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #00ff41;
        box-shadow: 0 0 20px #00ff41, 0 0 40px #00ff4180, 0 0 60px #00ff4140;
        animation: pulse 2s ease-in-out infinite;
    }
    
    .nucleotide-pair {
        position: absolute;
        height: 3px;
        background: linear-gradient(90deg, #00ff41, #00ff4180, #00ff41);
        box-shadow: 0 0 10px #00ff4180;
        transform-origin: left center;
    }
    
    @keyframes dnaRotate {
        0% { transform: rotateY(0deg); }
        100% { transform: rotateY(360deg); }
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.7; transform: scale(1.2); }
    }
    
    @keyframes float {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
    }
    
    .dna-helix-svg {
        animation: float 4s ease-in-out infinite;
    }
    
    /* Main Header */
    .main-header {
        font-family: 'Inter', sans-serif;
        font-size: 3rem;
        font-weight: 700;
        background: linear-gradient(135deg, #00ff41 0%, #00cc33 50%, #00ff41 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-align: center;
        margin-bottom: 0.5rem;
        text-shadow: 0 0 30px #00ff4140;
        letter-spacing: 2px;
    }
    
    .sub-header {
        font-family: 'Inter', sans-serif;
        font-size: 1.2rem;
        color: #00ff4180 !important;
        text-align: center;
        margin-bottom: 2rem;
        letter-spacing: 1px;
    }
    
    /* Metric Cards - Dark Theme */
    .metric-card {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 1px solid #00ff4130;
        padding: 1.5rem;
        border-radius: 15px;
        color: #00ff41;
        text-align: center;
        box-shadow: 0 0 20px #00ff4110, inset 0 0 20px #00ff4105;
        transition: all 0.3s ease;
    }
    
    .metric-card:hover {
        border-color: #00ff4160;
        box-shadow: 0 0 30px #00ff4120, inset 0 0 30px #00ff4110;
        transform: translateY(-2px);
    }
    
    /* Section Headers */
    .section-header {
        font-family: 'Inter', sans-serif;
        font-size: 1.5rem;
        font-weight: 600;
        color: #00ff41 !important;
        border-bottom: 2px solid #00ff4140;
        padding-bottom: 0.5rem;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    
    /* Info Boxes - Dark Theme */
    .info-box {
        background: linear-gradient(135deg, #0a192f 0%, #0d1b2a 100%);
        border-left: 4px solid #00ff41;
        padding: 1rem;
        border-radius: 0 12px 12px 0;
        margin: 1rem 0;
        color: #c0c0c0;
        box-shadow: 0 0 15px #00ff4110;
    }
    
    .warning-box {
        background: linear-gradient(135deg, #1a1a0a 0%, #2d2d0a 100%);
        border-left: 4px solid #ffd700;
        padding: 1rem;
        border-radius: 0 12px 12px 0;
        margin: 1rem 0;
        color: #ffd700;
    }
    
    .success-box {
        background: linear-gradient(135deg, #0a1a0a 0%, #0d2d0d 100%);
        border-left: 4px solid #00ff41;
        padding: 1rem;
        border-radius: 0 12px 12px 0;
        margin: 1rem 0;
        color: #00ff41;
    }
    
    /* Tabs - Dark Theme */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background: transparent;
    }
    
    .stTabs [data-baseweb="tab"] {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 1px solid #00ff4130;
        border-radius: 10px 10px 0 0;
        padding: 12px 24px;
        color: #00ff4180 !important;
        transition: all 0.3s ease;
    }
    
    .stTabs [data-baseweb="tab"]:hover {
        background: linear-gradient(135deg, #1a2a3e 0%, #1a3a4e 100%);
        border-color: #00ff4160;
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #00ff4120 0%, #00cc3320 100%) !important;
        border-color: #00ff41 !important;
        color: #00ff41 !important;
        box-shadow: 0 0 15px #00ff4130;
    }
    
    /* Buttons - Neon Green */
    .stButton > button {
        background: linear-gradient(135deg, #00ff4120 0%, #00cc3320 100%);
        border: 1px solid #00ff41;
        color: #00ff41;
        border-radius: 8px;
        padding: 0.5rem 1.5rem;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 0 10px #00ff4120;
    }
    
    .stButton > button:hover {
        background: linear-gradient(135deg, #00ff4140 0%, #00cc3340 100%);
        box-shadow: 0 0 20px #00ff4140, 0 0 40px #00ff4120;
        transform: translateY(-1px);
    }
    
    .stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #00ff41 0%, #00cc33 100%);
        color: #0a0a0a;
        font-weight: 700;
    }
    
    /* Text Colors */
    .stMarkdown, .stText, p, span, label {
        color: #c0c0c0 !important;
    }
    
    h1, h2, h3, h4, h5, h6 {
        color: #00ff41 !important;
    }
    
    /* DataFrames */
    .stDataFrame {
        background: #0a0a0a;
        border: 1px solid #00ff4130;
        border-radius: 10px;
    }
    
    /* Selectbox, Input */
    .stSelectbox > div > div,
    .stTextInput > div > div > input,
    .stNumberInput > div > div > input,
    .stTextArea > div > div > textarea {
        background: #1a1a2e !important;
        border: 1px solid #00ff4140 !important;
        color: #e0e0e0 !important;
        border-radius: 8px;
    }
    
    /* Metrics */
    [data-testid="stMetricValue"] {
        color: #00ff41 !important;
        font-family: 'Roboto Mono', monospace;
    }
    
    [data-testid="stMetricDelta"] {
        color: #00cc33 !important;
    }
    
    /* Expander */
    .streamlit-expanderHeader {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 1px solid #00ff4130;
        border-radius: 10px;
        color: #00ff41 !important;
    }
    
    /* Academic Footer */
    .academic-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: linear-gradient(180deg, transparent 0%, #0a0a0a 20%, #0a0a0a 100%);
        padding: 1.5rem 0 1rem 0;
        text-align: center;
        z-index: 1000;
    }
    
    .academic-credentials {
        font-family: 'Inter', sans-serif;
        font-size: 0.85rem;
        color: #00ff4180;
        letter-spacing: 2px;
        text-transform: uppercase;
        margin: 0;
        padding: 0.5rem;
        border-top: 1px solid #00ff4130;
        background: linear-gradient(90deg, transparent 0%, #00ff4110 50%, transparent 100%);
    }
    
    .credential-line {
        display: block;
        margin: 0.3rem 0;
    }
    
    .credential-title {
        color: #00ff41;
        font-weight: 600;
    }
    
    .credential-degree {
        color: #00cc33;
        font-weight: 500;
    }
    
    /* Scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: #0a0a0a;
    }
    
    ::-webkit-scrollbar-thumb {
        background: #00ff4140;
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: #00ff4160;
    }
    
    /* Radio buttons */
    .stRadio > div {
        background: transparent;
    }
    
    .stRadio > div > label {
        color: #c0c0c0 !important;
        background: #1a1a2e;
        border: 1px solid #00ff4120;
        border-radius: 8px;
        padding: 0.5rem 1rem;
        margin: 0.25rem 0;
        transition: all 0.3s ease;
    }
    
    .stRadio > div > label:hover {
        border-color: #00ff4160;
        background: #1a2a3e;
    }
    
    /* Slider */
    .stSlider > div > div > div {
        background: #00ff41 !important;
    }
    
    /* Multiselect */
    .stMultiSelect > div > div {
        background: #1a1a2e !important;
        border-color: #00ff4140 !important;
    }
    
    /* Progress bar */
    .stProgress > div > div > div {
        background: linear-gradient(90deg, #00ff41 0%, #00cc33 100%);
    }
    
    /* Code blocks */
    .stCodeBlock {
        background: #0a0a0a !important;
        border: 1px solid #00ff4130;
    }
    
    code {
        color: #00ff41 !important;
        background: #1a1a2e !important;
    }
    
    /* Alerts */
    .stAlert {
        background: #1a1a2e;
        border: 1px solid #00ff4140;
        border-radius: 10px;
    }
</style>
""", unsafe_allow_html=True)

def render_dna_helix_animation():
    """Render animated DNA helix with phosphorescent green color"""
    st.markdown('''
    <div class="dna-container">
        <svg class="dna-helix-svg" viewBox="0 0 200 150" width="350" height="200">
            <defs>
                <filter id="glow">
                    <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                    <feMerge>
                        <feMergeNode in="coloredBlur"/>
                        <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                </filter>
                <linearGradient id="phosphorGreen" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:#00ff41;stop-opacity:1" />
                    <stop offset="50%" style="stop-color:#00cc33;stop-opacity:0.8" />
                    <stop offset="100%" style="stop-color:#00ff41;stop-opacity:1" />
                </linearGradient>
            </defs>
            
            <!-- DNA Strand 1 -->
            <g filter="url(#glow)">
                <path d="M 30 20 Q 50 40 70 20 Q 90 0 110 20 Q 130 40 150 20 Q 170 0 190 20" 
                      stroke="url(#phosphorGreen)" stroke-width="3" fill="none">
                    <animate attributeName="d" 
                             values="M 30 20 Q 50 40 70 20 Q 90 0 110 20 Q 130 40 150 20 Q 170 0 190 20;
                                     M 30 25 Q 50 5 70 25 Q 90 45 110 25 Q 130 5 150 25 Q 170 45 190 25;
                                     M 30 20 Q 50 40 70 20 Q 90 0 110 20 Q 130 40 150 20 Q 170 0 190 20"
                             dur="3s" repeatCount="indefinite"/>
                </path>
            </g>
            
            <!-- DNA Strand 2 -->
            <g filter="url(#glow)">
                <path d="M 30 50 Q 50 30 70 50 Q 90 70 110 50 Q 130 30 150 50 Q 170 70 190 50" 
                      stroke="url(#phosphorGreen)" stroke-width="3" fill="none">
                    <animate attributeName="d" 
                             values="M 30 50 Q 50 30 70 50 Q 90 70 110 50 Q 130 30 150 50 Q 170 70 190 50;
                                     M 30 45 Q 50 65 70 45 Q 90 25 110 45 Q 130 65 150 45 Q 170 25 190 45;
                                     M 30 50 Q 50 30 70 50 Q 90 70 110 50 Q 130 30 150 50 Q 170 70 190 50"
                             dur="3s" repeatCount="indefinite"/>
                </path>
            </g>
            
            <!-- Connecting Base Pairs with Animation -->
            <g filter="url(#glow)" stroke="#00ff41" stroke-width="2" opacity="0.7">
                <line x1="40" y1="35" x2="40" y2="35">
                    <animate attributeName="y1" values="25;30;25" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="45;40;45" dur="3s" repeatCount="indefinite"/>
                </line>
                <line x1="60" y1="25" x2="60" y2="45">
                    <animate attributeName="y1" values="30;20;30" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="40;50;40" dur="3s" repeatCount="indefinite"/>
                </line>
                <line x1="80" y1="15" x2="80" y2="55">
                    <animate attributeName="y1" values="15;25;15" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="55;45;55" dur="3s" repeatCount="indefinite"/>
                </line>
                <line x1="100" y1="25" x2="100" y2="45">
                    <animate attributeName="y1" values="25;15;25" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="45;55;45" dur="3s" repeatCount="indefinite"/>
                </line>
                <line x1="120" y1="35" x2="120" y2="35">
                    <animate attributeName="y1" values="35;25;35" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="35;45;35" dur="3s" repeatCount="indefinite"/>
                </line>
                <line x1="140" y1="25" x2="140" y2="45">
                    <animate attributeName="y1" values="25;35;25" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="45;35;45" dur="3s" repeatCount="indefinite"/>
                </line>
                <line x1="160" y1="15" x2="160" y2="55">
                    <animate attributeName="y1" values="15;25;15" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="55;45;55" dur="3s" repeatCount="indefinite"/>
                </line>
                <line x1="180" y1="25" x2="180" y2="45">
                    <animate attributeName="y1" values="25;15;25" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="y2" values="45;55;45" dur="3s" repeatCount="indefinite"/>
                </line>
            </g>
            
            <!-- Nucleotide Dots -->
            <g filter="url(#glow)">
                <circle cx="40" cy="25" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="25;30;25" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="1;0.6;1" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="40" cy="45" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="45;40;45" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.6;1;0.6" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="80" cy="15" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="15;25;15" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="1;0.6;1" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="80" cy="55" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="55;45;55" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.6;1;0.6" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="120" cy="35" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="35;25;35" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="1;0.6;1" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="120" cy="35" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="35;45;35" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.6;1;0.6" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="160" cy="15" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="15;25;15" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="1;0.6;1" dur="2s" repeatCount="indefinite"/>
                </circle>
                <circle cx="160" cy="55" r="4" fill="#00ff41">
                    <animate attributeName="cy" values="55;45;55" dur="3s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.6;1;0.6" dur="2s" repeatCount="indefinite"/>
                </circle>
            </g>
            
            <!-- Second DNA Helix Layer (offset) -->
            <g transform="translate(0, 70)" filter="url(#glow)" opacity="0.8">
                <path d="M 20 20 Q 40 0 60 20 Q 80 40 100 20 Q 120 0 140 20 Q 160 40 180 20" 
                      stroke="url(#phosphorGreen)" stroke-width="2.5" fill="none">
                    <animate attributeName="d" 
                             values="M 20 20 Q 40 0 60 20 Q 80 40 100 20 Q 120 0 140 20 Q 160 40 180 20;
                                     M 20 25 Q 40 45 60 25 Q 80 5 100 25 Q 120 45 140 25 Q 160 5 180 25;
                                     M 20 20 Q 40 0 60 20 Q 80 40 100 20 Q 120 0 140 20 Q 160 40 180 20"
                             dur="4s" repeatCount="indefinite"/>
                </path>
                <path d="M 20 50 Q 40 70 60 50 Q 80 30 100 50 Q 120 70 140 50 Q 160 30 180 50" 
                      stroke="url(#phosphorGreen)" stroke-width="2.5" fill="none">
                    <animate attributeName="d" 
                             values="M 20 50 Q 40 70 60 50 Q 80 30 100 50 Q 120 70 140 50 Q 160 30 180 50;
                                     M 20 45 Q 40 25 60 45 Q 80 65 100 45 Q 120 25 140 45 Q 160 65 180 45;
                                     M 20 50 Q 40 70 60 50 Q 80 30 100 50 Q 120 70 140 50 Q 160 30 180 50"
                             dur="4s" repeatCount="indefinite"/>
                </path>
            </g>
        </svg>
    </div>
    ''', unsafe_allow_html=True)

def render_academic_footer():
    """Render academic credentials footer"""
    st.markdown('''
    <div class="academic-footer">
        <div class="academic-credentials">
            <span class="credential-line">
                <span class="credential-title">Forensic Medicine</span> 
                <span class="credential-degree">Ph.D., M.D.</span>
                &nbsp;&nbsp;|&nbsp;&nbsp;
                <span class="credential-title">Software Engineering</span> 
                <span class="credential-degree">M.Sc.</span>
                &nbsp;&nbsp;|&nbsp;&nbsp;
                <span class="credential-title">Health Law</span> 
                <span class="credential-degree">J.D., M.D.</span>
            </span>
        </div>
    </div>
    <div style="height: 80px;"></div>
    ''', unsafe_allow_html=True)

@st.cache_resource
def init_components():
    """Initialize all analysis components"""
    clock_calc = EpigeneticClockCalculator()
    ml_predictor = EnsembleAgePredictor(n_estimators=50, random_state=42)
    data_processor = MethylationDataProcessor()
    stats_analyzer = StatisticalAnalyzer()
    visualizer = EpigeneticVisualizer()
    ref_db = ReferenceDatabase()
    report_gen = ReportGenerator()
    db_manager = DatabaseManager()
    longitudinal = LongitudinalAnalyzer()
    gsea = GSEAnalyzer()
    clinical_decision = ClinicalDecisionSupport()
    multiomics = MultiOmicsIntegrator()
    postmortem = PostmortemValidator()
    forensic = ForensicApplications()
    ders_moderator = EmotionRegulationModerator()
    scsb_moderator = SelfControlModerator()
    reversibility = ReversibilityAnalysis()
    clinical_covariates = ClinicalCovariates()
    tissue_clock_calc = TissueSpecificClockCalculator()
    cross_tissue_normalizer = CrossTissueNormalizer()
    tissue_discordance = TissueAgeDiscordanceAnalyzer()
    audit_ledger = BlockchainAuditLedger()
    chain_of_custody = ForensicChainOfCustody()
    role_ui = RoleBasedUI()
    
    X_train, y_train = generate_synthetic_training_data(n_samples=500, n_cpgs=200)
    ml_predictor.fit(X_train, y_train)
    
    return {
        'clock_calc': clock_calc,
        'ml_predictor': ml_predictor,
        'data_processor': data_processor,
        'stats_analyzer': stats_analyzer,
        'visualizer': visualizer,
        'ref_db': ref_db,
        'report_gen': report_gen,
        'db_manager': db_manager,
        'longitudinal': longitudinal,
        'gsea': gsea,
        'clinical_decision': clinical_decision,
        'multiomics': multiomics,
        'postmortem': postmortem,
        'forensic': forensic,
        'ders_moderator': ders_moderator,
        'scsb_moderator': scsb_moderator,
        'reversibility': reversibility,
        'clinical_covariates': clinical_covariates,
        'tissue_clock_calc': tissue_clock_calc,
        'cross_tissue_normalizer': cross_tissue_normalizer,
        'tissue_discordance': tissue_discordance,
        'audit_ledger': audit_ledger,
        'chain_of_custody': chain_of_custody,
        'role_ui': role_ui
    }

def main():
    components = init_components()
    
    render_dna_helix_animation()
    st.markdown('<p class="main-header">🧬 EpiClock Prototype</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">DNA Metilasyon Tabanlı Epigenetik Yaş İvmelenmesi Analiz Platformu</p>', unsafe_allow_html=True)
    
    with st.sidebar:
        st.markdown("### 🧬 EpiClock")
        st.markdown("### 📊 Analiz Modülleri")
        
        analysis_mode = st.radio(
            "Analiz Türü Seçin:",
            ["🏠 Ana Sayfa",
             "👤 Bireysel Analiz",
             "📁 Toplu Analiz",
             "📈 Referans Veritabanı",
             "🔬 Diferansiyel Metilasyon",
             "🧪 Mediyasyon Analizi",
             "📊 Model Performansı",
             "📉 Longitudinal Takip",
             "🧬 GSEA Pathway Analizi",
             "💊 Klinik Karar Destek",
             "🔗 Multi-Omik Entegrasyon",
             "🧠 Postmortem Validasyon",
             "⚖️ Moderasyon Analizi",
             "🔄 Tersine Çevrilebilirlik",
             "📊 Klinik Kovaryatlar",
             "🫀 Doku-Spesifik Saatler",
             "🔐 Blockchain Denetim",
             "🗄️ Veritabanı Yönetimi",
             "📋 Rapor Oluştur"],
            index=0
        )
        
        st.markdown("---")
        st.markdown("### ⚙️ Ayarlar")
        
        selected_clocks = st.multiselect(
            "Epigenetik Saatler:",
            ["Horvath", "Hannum", "PhenoAge", "GrimAge", "DunedinPACE"],
            default=["GrimAge", "PhenoAge", "DunedinPACE"]
        )
        
        significance_level = st.slider(
            "İstatistiksel Anlamlılık (α):",
            min_value=0.01,
            max_value=0.10,
            value=0.05,
            step=0.01
        )
        
        st.markdown("---")
        st.markdown("### 📚 Hakkında")
        st.markdown("""
        **EpiClock Prototype v1.0**
        
        Bu platform, DNA metilasyon verilerini 
        kullanarak epigenetik yaş ivmelenmesini 
        tespit eder.
        
        **Desteklenen Saatler:**
        - Horvath (353 CpG)
        - Hannum (71 CpG)
        - PhenoAge (513 CpG)
        - GrimAge (1030 CpG)
        - DunedinPACE (173 CpG)
        
        **Referans Veritabanı:**
        10,542 DNA metilasyon profili
        """)
    
    if "🏠 Ana Sayfa" in analysis_mode:
        render_home_page(components)
    elif "👤 Bireysel Analiz" in analysis_mode:
        render_individual_analysis(components, selected_clocks)
    elif "📁 Toplu Analiz" in analysis_mode:
        render_batch_analysis(components, selected_clocks)
    elif "📈 Referans Veritabanı" in analysis_mode:
        render_reference_database(components)
    elif "🔬 Diferansiyel Metilasyon" in analysis_mode:
        render_differential_methylation(components, significance_level)
    elif "🧪 Mediyasyon Analizi" in analysis_mode:
        render_mediation_analysis(components)
    elif "📊 Model Performansı" in analysis_mode:
        render_model_performance(components)
    elif "📉 Longitudinal Takip" in analysis_mode:
        render_longitudinal_analysis(components)
    elif "🧬 GSEA Pathway Analizi" in analysis_mode:
        render_gsea_analysis(components)
    elif "💊 Klinik Karar Destek" in analysis_mode:
        render_clinical_decision_support(components)
    elif "🔗 Multi-Omik Entegrasyon" in analysis_mode:
        render_multiomics_analysis(components)
    elif "🧠 Postmortem Validasyon" in analysis_mode:
        render_postmortem_validation(components)
    elif "⚖️ Moderasyon Analizi" in analysis_mode:
        render_moderation_analysis(components)
    elif "🔄 Tersine Çevrilebilirlik" in analysis_mode:
        render_reversibility_analysis(components)
    elif "📊 Klinik Kovaryatlar" in analysis_mode:
        render_clinical_covariates(components)
    elif "🫀 Doku-Spesifik Saatler" in analysis_mode:
        render_tissue_specific_clocks(components)
    elif "🔐 Blockchain Denetim" in analysis_mode:
        render_blockchain_audit(components)
    elif "🗄️ Veritabanı Yönetimi" in analysis_mode:
        render_database_management(components)
    elif "📋 Rapor Oluştur" in analysis_mode:
        render_report_generator(components)
    
    render_academic_footer()


def render_home_page(components):
    """Render the home page with overview and quick stats"""
    
    st.markdown("""
    <div style="background: linear-gradient(135deg, #fff3cd 0%, #ffeeba 100%); 
                border: 2px solid #ffc107; border-radius: 10px; padding: 1rem; margin-bottom: 1.5rem;">
    <h4 style="color: #856404; margin: 0;">⚠️ PROTOTIP PLATFORMU</h4>
    <p style="color: #856404; margin: 0.5rem 0 0 0; font-size: 0.9rem;">
    Bu platform, epigenetik yaş analizi metodolojisini ve iş akışını göstermek için 
    <b>SİMÜLE EDİLMİŞ VERİLER</b> kullanmaktadır. Saat katsayıları ve referans veritabanı, 
    yayınlanmış araştırma istatistiklerine dayalı olarak simüle edilmiştir. 
    Gerçek klinik veya araştırma kullanımı için, gerçek katsayılar ve veriler uygun 
    akademik kanallardan temin edilmelidir.
    </p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("### 🎯 Platform Özellikleri")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="Referans Profil Sayısı",
            value="10,542",
            delta="15 bağımsız veri seti"
        )
    
    with col2:
        st.metric(
            label="Epigenetik Saat",
            value="5",
            delta="En güncel algoritmalar"
        )
    
    with col3:
        st.metric(
            label="ML Model MAE",
            value="2.1 yıl",
            delta="R² = 0.96"
        )
    
    with col4:
        st.metric(
            label="Madde Kategorisi",
            value="6",
            delta="+ Kontrol grubu"
        )
    
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 📊 Madde Tipine Göre EAA Etkileri")
        
        ref_db = components['ref_db']
        effect_summary = ref_db.get_substance_effect_summary()
        
        visualizer = components['visualizer']
        
        effect_summary['substance_tr'] = effect_summary['substance'].map({
            'polysubstance': 'Çoklu Madde',
            'methamphetamine': 'Metamfetamin',
            'cocaine': 'Kokain',
            'alcohol': 'Alkol',
            'opioids': 'Opioid',
            'cannabis': 'Kannabis'
        })
        
        import plotly.graph_objects as go
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            y=effect_summary['substance_tr'],
            x=effect_summary['effect_vs_control'],
            orientation='h',
            marker=dict(
                color=effect_summary['effect_vs_control'],
                colorscale='Reds',
                showscale=True,
                colorbar=dict(title="EAA (yıl)")
            ),
            error_x=dict(
                type='data',
                symmetric=False,
                array=effect_summary['ci_upper'] - effect_summary['effect_vs_control'],
                arrayminus=effect_summary['effect_vs_control'] - effect_summary['ci_lower']
            ),
            hovertemplate="<b>%{y}</b><br>EAA: %{x:.1f} yıl<br>n=%{customdata}<extra></extra>",
            customdata=effect_summary['n_samples']
        ))
        
        fig.update_layout(
            title="GrimAge Epigenetik Yaş İvmelenmesi (Kontrole Göre)",
            xaxis_title="Epigenetik Yaş İvmelenmesi (yıl)",
            yaxis_title="",
            template="plotly_white",
            height=400
        )
        
        st.plotly_chart(fig, width='stretch')
    
    with col2:
        st.markdown("### 🎯 Epigenetik Saat Performansları")
        
        clock_perf = ref_db.get_clock_performance_summary()
        
        fig = go.Figure()
        
        fig.add_trace(go.Bar(
            name='MAE (yıl)',
            x=clock_perf['clock'],
            y=clock_perf['mae'],
            marker_color='steelblue',
            yaxis='y'
        ))
        
        fig.add_trace(go.Scatter(
            name='R²',
            x=clock_perf['clock'],
            y=clock_perf['r_squared'],
            mode='lines+markers',
            marker=dict(size=12, color='coral'),
            line=dict(width=3),
            yaxis='y2'
        ))
        
        fig.update_layout(
            title="Epigenetik Saat Doğruluk Karşılaştırması",
            xaxis_title="Epigenetik Saat",
            yaxis=dict(title="MAE (yıl)", side='left'),
            yaxis2=dict(title="R²", side='right', overlaying='y', range=[0.85, 1.0]),
            template="plotly_white",
            legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
            height=400
        )
        
        st.plotly_chart(fig, width='stretch')
    
    st.markdown("---")
    
    st.markdown("### 📖 Metodoloji ve Bilimsel Arka Plan")
    
    with st.expander("DNA Metilasyonu ve Epigenetik Saatler", expanded=False):
        st.markdown("""
        **DNA Metilasyonu Nedir?**
        
        DNA metilasyonu, DNA'nın sitozin bazlarına metil gruplarının (CH₃) kovalent bağlanmasıyla 
        karakterize edilen epigenetik bir modifikasyondur. İnsan genomunda yaklaşık 28 milyon CpG 
        bölgesinin %60-80'i metillenmiş durumdadır.
        
        **Epigenetik Saatler**
        
        Belirli CpG bölgelerindeki metilasyon seviyeleri, kronolojik yaşla yüksek korelasyon gösterir. 
        Bu paternler kullanılarak biyolojik yaş tahmin edilebilir:
        
        | Saat | Yıl | CpG Sayısı | Özellik |
        |------|-----|------------|---------|
        | Horvath | 2013 | 353 | Pan-doku, genel biyolojik yaş |
        | Hannum | 2013 | 71 | Kan-spesifik |
        | PhenoAge | 2018 | 513 | Fenotipik yaş, hastalık riski |
        | GrimAge | 2019 | 1030 | Mortalite tahmini |
        | DunedinPACE | 2022 | 173 | Yaşlanma hızı |
        """)
    
    with st.expander("Madde Kullanımı ve Epigenetik Yaş İvmelenmesi", expanded=False):
        st.markdown("""
        **Madde Kullanım Bozuklukları ve Biyolojik Yaşlanma**
        
        Kronik madde kullanımı, DNA metilasyon paternlerinde sistematik değişikliklere yol açarak 
        epigenetik yaş ivmelenmesine (EAA) neden olur.
        
        **Araştırma Bulguları (10,542 profil analizi):**
        
        - **Çoklu Madde:** +7.3 yıl GrimAge ivmelenmesi (en yüksek etki)
        - **Metamfetamin:** +6.2 yıl
        - **Kokain:** +4.1 yıl
        - **Alkol:** +3.6 yıl
        - **Opioid:** +2.9 yıl
        - **Kannabis:** +0.8 yıl (en düşük etki)
        
        **Fizyolojik Mekanizmalar:**
        - İnsülin direnci (HOMA-IR)
        - HPA eksen disregülasyonu (Kortizol/ACTH)
        - Sistemik inflamasyon (CRP, IL-6, TNF-α)
        - Oksidatif stres
        - Telomer kısalması
        """)
    
    with st.expander("Platform Kullanım Kılavuzu", expanded=False):
        st.markdown("""
        **1. Bireysel Analiz**
        - Tek bir hastanın verilerini girerek epigenetik yaş hesaplayın
        - Tüm 5 epigenetik saat sonuçlarını görüntüleyin
        - Referans popülasyonla karşılaştırma yapın
        
        **2. Toplu Analiz**
        - CSV/Excel formatında DNA metilasyon verisi yükleyin
        - Çoklu örnek analizi gerçekleştirin
        - Grup karşılaştırmaları ve istatistiksel testler
        
        **3. Diferansiyel Metilasyon Analizi**
        - Madde grupları arasında CpG farklılıklarını tespit edin
        - Volcano plot ve heatmap görselleştirmeleri
        
        **4. Mediyasyon/Moderasyon Analizi**
        - Fizyolojik ve psikolojik faktörlerin etkilerini analiz edin
        - Müdahale hedeflerini belirleyin
        
        **5. PDF Rapor**
        - Kapsamlı klinik raporlar oluşturun
        - Sonuçları dışa aktarın
        """)


def render_individual_analysis(components, selected_clocks):
    """Render individual sample analysis page"""
    
    st.markdown("### 👤 Bireysel Epigenetik Yaş Analizi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modülde tek bir hastanın demografik bilgilerini girerek 
    epigenetik yaş hesaplaması yapabilir ve referans popülasyonla karşılaştırabilirsiniz.
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 📝 Hasta Bilgileri")
        
        patient_id = st.text_input("Hasta ID:", value="HASTA_001")
        chronological_age = st.number_input("Kronolojik Yaş:", min_value=18, max_value=100, value=45)
        sex = st.selectbox("Cinsiyet:", ["Erkek", "Kadın"])
        sex_code = "M" if sex == "Erkek" else "F"
        
        substance_type = st.selectbox(
            "Madde Maruziyeti:",
            ["Kontrol (Maruziyetsiz)", "Alkol Kullanım Bozukluğu", "Kokain Kullanımı", 
             "Opioid Kullanımı", "Metamfetamin Kullanımı", "Kannabis Kullanımı", 
             "Çoklu Madde Kullanımı"]
        )
        
        substance_map = {
            "Kontrol (Maruziyetsiz)": "control",
            "Alkol Kullanım Bozukluğu": "alcohol",
            "Kokain Kullanımı": "cocaine",
            "Opioid Kullanımı": "opioids",
            "Metamfetamin Kullanımı": "methamphetamine",
            "Kannabis Kullanımı": "cannabis",
            "Çoklu Madde Kullanımı": "polysubstance"
        }
        substance_code = substance_map[substance_type]
        
        smoking_years = st.slider("Sigara Paket-Yılı:", 0, 60, 5)
    
    with col2:
        st.markdown("#### 🧪 Klinik Biyobelirteçler (Opsiyonel)")
        
        use_biomarkers = st.checkbox("Klinik biyobelirteçleri dahil et (PhenoAge için)")
        
        if use_biomarkers:
            col_a, col_b = st.columns(2)
            with col_a:
                albumin = st.number_input("Albumin (g/dL):", min_value=2.0, max_value=6.0, value=4.0)
                creatinine = st.number_input("Kreatinin (mg/dL):", min_value=0.3, max_value=3.0, value=1.0)
                glucose = st.number_input("Glukoz (mg/dL):", min_value=50.0, max_value=300.0, value=95.0)
                crp = st.number_input("CRP (mg/L):", min_value=0.1, max_value=50.0, value=1.5)
            with col_b:
                lymphocyte = st.number_input("Lenfosit (%):", min_value=5.0, max_value=60.0, value=30.0)
                mcv = st.number_input("MCV (fL):", min_value=70.0, max_value=110.0, value=90.0)
                rdw = st.number_input("RDW (%):", min_value=10.0, max_value=20.0, value=13.0)
                wbc = st.number_input("WBC (10³/µL):", min_value=2.0, max_value=15.0, value=6.0)
            
            clinical_biomarkers = {
                'albumin': albumin,
                'creatinine': creatinine,
                'glucose': glucose,
                'crp': crp,
                'lymphocyte_percent': lymphocyte,
                'mcv': mcv,
                'rdw': rdw,
                'white_blood_cell': wbc
            }
        else:
            clinical_biomarkers = None
    
    st.markdown("---")
    
    if st.button("🔬 Epigenetik Yaş Hesapla", type="primary", width='stretch'):
        
        with st.spinner("Epigenetik saatler hesaplanıyor..."):
            
            clock_calc = components['clock_calc']
            ref_db = components['ref_db']
            visualizer = components['visualizer']
            
            dummy_methylation = pd.DataFrame(
                np.random.beta(2, 5, (1, 500)),
                columns=[f"cg{str(i).zfill(8)}" for i in range(500)]
            )
            
            base_results = clock_calc.calculate_all_clocks(
                dummy_methylation,
                chronological_age,
                sex_code,
                smoking_years,
                clinical_biomarkers
            )
            
            if substance_code != 'control':
                clock_results = clock_calc.simulate_substance_effect(
                    base_results, 
                    substance_code, 
                    severity=1.0
                )
            else:
                clock_results = base_results
            
            if 'analysis_results' not in st.session_state:
                st.session_state['analysis_results'] = {}
            
            st.session_state['analysis_results'] = {
                'patient_info': {
                    'patient_id': patient_id,
                    'chronological_age': chronological_age,
                    'sex': sex_code,
                    'substance_type': substance_code,
                    'tissue_type': 'blood'
                },
                'clock_results': clock_results,
                'timestamp': datetime.now()
            }
        
        st.success("✅ Analiz tamamlandı!")
        
        st.markdown("### 📊 Epigenetik Saat Sonuçları")
        
        result_cols = st.columns(len(clock_results))
        
        for i, (clock_name, result) in enumerate(clock_results.items()):
            with result_cols[i]:
                eaa = result.age_acceleration
                if clock_name == 'dunedinpace':
                    delta_color = "inverse" if eaa > 0.05 else "normal"
                    st.metric(
                        label=result.clock_name,
                        value=f"{result.predicted_age:.2f}",
                        delta=f"Hız: {eaa:+.2f}",
                        delta_color=delta_color
                    )
                else:
                    delta_color = "inverse" if eaa > 2 else "normal"
                    st.metric(
                        label=result.clock_name,
                        value=f"{result.predicted_age:.1f} yıl",
                        delta=f"EAA: {eaa:+.1f} yıl",
                        delta_color=delta_color
                    )
        
        st.markdown("---")
        
        tab1, tab2, tab3 = st.tabs(["📈 Görselleştirmeler", "📋 Detaylı Sonuçlar", "🎯 Referans Karşılaştırması"])
        
        with tab1:
            col1, col2 = st.columns(2)
            
            with col1:
                eaa_values = {name: r.age_acceleration for name, r in clock_results.items() 
                             if name != 'dunedinpace'}
                radar_fig = visualizer.plot_clock_comparison_radar(eaa_values, patient_id)
                st.plotly_chart(radar_fig, width='stretch')
            
            with col2:
                import plotly.graph_objects as go
                
                clock_names = [r.clock_name for r in clock_results.values()]
                predicted_ages = [r.predicted_age for r in clock_results.values()]
                eaa_vals = [r.age_acceleration for r in clock_results.values()]
                
                colors = ['green' if e < 2 else 'orange' if e < 5 else 'red' for e in eaa_vals]
                
                fig = go.Figure(data=[
                    go.Bar(
                        x=clock_names,
                        y=predicted_ages,
                        marker_color=colors,
                        text=[f"{p:.1f}" for p in predicted_ages],
                        textposition='outside'
                    )
                ])
                
                fig.add_hline(y=chronological_age, line_dash="dash", 
                             annotation_text=f"Kronolojik Yaş: {chronological_age}")
                
                fig.update_layout(
                    title="Epigenetik Yaş Tahminleri",
                    xaxis_title="Epigenetik Saat",
                    yaxis_title="Tahmin Edilen Yaş (yıl)",
                    template="plotly_white",
                    height=400
                )
                
                st.plotly_chart(fig, width='stretch')
        
        with tab2:
            results_df = pd.DataFrame([
                {
                    'Epigenetik Saat': r.clock_name,
                    'Tahmin Edilen Yaş': f"{r.predicted_age:.2f}",
                    'Kronolojik Yaş': r.chronological_age,
                    'Yaş İvmelenmesi (EAA)': f"{r.age_acceleration:+.2f}",
                    '95% GA Alt': f"{r.confidence_interval[0]:.2f}",
                    '95% GA Üst': f"{r.confidence_interval[1]:.2f}",
                    'CpG Sayısı': r.cpg_count,
                    'R²': r.r_squared,
                    'MAE': r.mae,
                    'Yorum': clock_calc.get_eaa_interpretation(r.age_acceleration, r.clock_name)
                }
                for r in clock_results.values()
            ])
            
            st.dataframe(results_df, width='stretch')
        
        with tab3:
            grimage_result = clock_results.get('grimage')
            if grimage_result:
                comparison = ref_db.compare_to_reference(
                    grimage_result.age_acceleration,
                    substance_code,
                    'grimage',
                    chronological_age,
                    sex_code
                )
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Persentil", f"{comparison.percentile:.0f}%")
                with col2:
                    st.metric("Z-Skoru", f"{comparison.z_score:.2f}")
                with col3:
                    st.metric("Benzer Örnek Sayısı", comparison.similar_samples)
                
                if comparison.percentile > 75:
                    st.markdown(f"""
                    <div class="warning-box">
                    <b>⚠️ Dikkat:</b> {comparison.interpretation}
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="success-box">
                    <b>✅ Sonuç:</b> {comparison.interpretation}
                    </div>
                    """, unsafe_allow_html=True)


def render_batch_analysis(components, selected_clocks):
    """Render batch analysis page for multiple samples"""
    
    st.markdown("### 📁 Toplu Örnek Analizi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modülde birden fazla örneğin DNA metilasyon verilerini yükleyerek 
    toplu analiz gerçekleştirebilir, grup karşılaştırmaları yapabilirsiniz.
    </div>
    """, unsafe_allow_html=True)
    
    tab1, tab2 = st.tabs(["📤 Veri Yükle", "🔄 Demo Veri Kullan"])
    
    with tab1:
        uploaded_file = st.file_uploader(
            "DNA Metilasyon Verisi Yükle (CSV/Excel):",
            type=['csv', 'xlsx', 'xls'],
            help="İlk sütun örnek ID, ilk satır CpG ID olmalıdır"
        )
        
        if uploaded_file:
            try:
                if uploaded_file.name.endswith('.csv'):
                    data = pd.read_csv(uploaded_file, index_col=0)
                else:
                    data = pd.read_excel(uploaded_file, index_col=0)
                
                st.success(f"✅ {data.shape[0]} örnek, {data.shape[1]} CpG yüklendi")
                
                with st.expander("Veri Önizleme"):
                    st.dataframe(data.head(10))
                    
            except Exception as e:
                st.error(f"Veri yüklenirken hata: {str(e)}")
    
    with tab2:
        st.markdown("#### Demo Veri Seti Oluştur")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            n_samples = st.number_input("Örnek Sayısı:", min_value=50, max_value=1000, value=200)
        with col2:
            n_cpgs = st.number_input("CpG Sayısı:", min_value=100, max_value=5000, value=500)
        with col3:
            include_substances = st.checkbox("Madde grupları dahil et", value=True)
        
        if st.button("🎲 Demo Veri Oluştur", type="primary"):
            with st.spinner("Demo veri seti oluşturuluyor..."):
                data_processor = components['data_processor']
                
                if include_substances:
                    methylation_data, metadata = data_processor.generate_sample_data(
                        n_samples=n_samples,
                        n_cpgs=n_cpgs,
                        include_metadata=True
                    )
                else:
                    methylation_data, metadata = data_processor.generate_sample_data(
                        n_samples=n_samples,
                        n_cpgs=n_cpgs,
                        include_metadata=True,
                        substance_distribution={'control': 1.0}
                    )
                
                st.session_state['batch_data'] = methylation_data
                st.session_state['batch_metadata'] = metadata
                
            st.success(f"✅ {n_samples} örnekli demo veri seti oluşturuldu!")
    
    if 'batch_data' in st.session_state:
        st.markdown("---")
        st.markdown("### 📊 Toplu Analiz")
        
        methylation_data = st.session_state['batch_data']
        metadata = st.session_state['batch_metadata']
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Veri Özeti:**")
            st.write(f"- Örnek sayısı: {len(methylation_data)}")
            st.write(f"- CpG sayısı: {methylation_data.shape[1]}")
            if metadata is not None:
                st.write(f"- Yaş aralığı: {metadata['chronological_age'].min():.0f} - {metadata['chronological_age'].max():.0f}")
        
        with col2:
            if metadata is not None and 'substance_type' in metadata.columns:
                st.markdown("**Grup Dağılımı:**")
                group_counts = metadata['substance_type'].value_counts()
                st.bar_chart(group_counts)
        
        if st.button("🔬 Toplu Analiz Başlat", type="primary", width='stretch'):
            
            with st.spinner("Toplu analiz gerçekleştiriliyor..."):
                
                clock_calc = components['clock_calc']
                stats_analyzer = components['stats_analyzer']
                visualizer = components['visualizer']
                
                all_results = []
                
                progress_bar = st.progress(0)
                
                for i, (sample_id, row) in enumerate(metadata.iterrows()):
                    sample_methylation = methylation_data.loc[[sample_id]]
                    
                    base_results = clock_calc.calculate_all_clocks(
                        sample_methylation,
                        row['chronological_age'],
                        row['sex'],
                        row.get('smoking_pack_years', 0)
                    )
                    
                    clock_results = clock_calc.simulate_substance_effect(
                        base_results,
                        row['substance_type'],
                        severity=1.0
                    )
                    
                    result_row = {
                        'sample_id': sample_id,
                        'chronological_age': row['chronological_age'],
                        'sex': row['sex'],
                        'substance_type': row['substance_type']
                    }
                    
                    for clock_name, result in clock_results.items():
                        result_row[f'{clock_name}_predicted'] = result.predicted_age
                        result_row[f'{clock_name}_eaa'] = result.age_acceleration
                    
                    all_results.append(result_row)
                    
                    progress_bar.progress((i + 1) / len(metadata))
                
                results_df = pd.DataFrame(all_results)
                st.session_state['batch_results'] = results_df
            
            st.success("✅ Toplu analiz tamamlandı!")
            
            st.markdown("### 📈 Analiz Sonuçları")
            
            tab1, tab2, tab3 = st.tabs(["📊 Grup Karşılaştırması", "📋 Detaylı Sonuçlar", "📥 Dışa Aktar"])
            
            with tab1:
                if 'substance_type' in results_df.columns:
                    group_stats = results_df.groupby('substance_type').agg({
                        'grimage_eaa': ['mean', 'std', 'count']
                    }).round(2)
                    group_stats.columns = ['Ortalama EAA', 'Std', 'N']
                    group_stats = group_stats.reset_index()
                    
                    eaa_values = results_df['grimage_eaa'].values
                    group_labels = results_df['substance_type'].values
                    
                    violin_fig = visualizer.plot_eaa_violin(eaa_values, group_labels)
                    st.plotly_chart(violin_fig, width='stretch')
                    
                    comparison_df = stats_analyzer.compare_groups(
                        eaa_values, group_labels, 'control'
                    )
                    
                    st.markdown("**İstatistiksel Karşılaştırma (vs Kontrol):**")
                    st.dataframe(comparison_df, width='stretch')
            
            with tab2:
                st.dataframe(results_df, width='stretch')
            
            with tab3:
                csv = results_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="📥 CSV Olarak İndir",
                    data=csv,
                    file_name=f"epiclock_batch_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
                
                buffer = io.BytesIO()
                with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
                    results_df.to_excel(writer, sheet_name='Sonuçlar', index=False)
                    if 'substance_type' in results_df.columns:
                        comparison_df.to_excel(writer, sheet_name='Grup Karşılaştırması', index=False)
                
                st.download_button(
                    label="📥 Excel Olarak İndir",
                    data=buffer.getvalue(),
                    file_name=f"epiclock_batch_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )


def render_reference_database(components):
    """Render reference database exploration page"""
    
    st.markdown("### 📈 Referans Veritabanı")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modülde 10,542 DNA metilasyon profilinden oluşan referans veritabanını 
    inceleyebilir, madde grupları arasındaki farklılıkları analiz edebilirsiniz.
    </div>
    """, unsafe_allow_html=True)
    
    ref_db = components['ref_db']
    visualizer = components['visualizer']
    
    summary = ref_db.get_database_summary()
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Toplam Örnek", f"{summary['total_samples']:,}")
    with col2:
        st.metric("Madde Kategorisi", len(summary['substance_distribution']))
    with col3:
        st.metric("Yaş Aralığı", f"{summary['age_range'][0]:.0f}-{summary['age_range'][1]:.0f}")
    with col4:
        st.metric("En İyi Model MAE", f"{summary['clock_performance']['ensemble']['mae']} yıl")
    
    st.markdown("---")
    
    tab1, tab2, tab3, tab4 = st.tabs([
        "📊 Grup Dağılımları", 
        "📈 Yaş Stratifikasyonu", 
        "🔍 Detaylı İstatistikler",
        "🎲 Sentetik Kohort"
    ])
    
    with tab1:
        st.markdown("#### Madde Tipine Göre Örnek Dağılımı")
        
        import plotly.graph_objects as go
        
        substances = list(summary['substance_distribution'].keys())
        counts = list(summary['substance_distribution'].values())
        
        substance_labels = {
            'control': 'Kontrol',
            'alcohol': 'Alkol',
            'cocaine': 'Kokain',
            'opioids': 'Opioid',
            'methamphetamine': 'Metamfetamin',
            'cannabis': 'Kannabis',
            'polysubstance': 'Çoklu Madde'
        }
        
        labels_tr = [substance_labels.get(s, s) for s in substances]
        
        colors = [visualizer.SUBSTANCE_COLORS.get(s, '#888888') for s in substances]
        
        fig = go.Figure(data=[go.Pie(
            labels=labels_tr,
            values=counts,
            marker_colors=colors,
            hole=0.4,
            textinfo='label+percent',
            textposition='outside'
        )])
        
        fig.update_layout(
            title="Referans Veritabanı Kompozisyonu",
            template="plotly_white",
            height=500
        )
        
        st.plotly_chart(fig, width='stretch')
        
        effect_summary = ref_db.get_substance_effect_summary()
        st.markdown("#### Madde Etkisi Özeti")
        st.dataframe(effect_summary, width='stretch')
    
    with tab2:
        st.markdown("#### Yaş Gruplarına Göre EAA İstatistikleri")
        
        selected_substance = st.selectbox(
            "Madde Tipi:",
            ["Tümü"] + list(summary['substance_distribution'].keys())
        )
        
        if selected_substance == "Tümü":
            age_stats = ref_db.get_age_stratified_statistics()
        else:
            age_stats = ref_db.get_age_stratified_statistics(selected_substance)
        
        st.dataframe(age_stats, width='stretch')
    
    with tab3:
        st.markdown("#### Detaylı Referans İstatistikleri")
        
        selected_substance_detail = st.selectbox(
            "İstatistik için madde tipi seçin:",
            list(summary['substance_distribution'].keys()),
            key="detail_substance"
        )
        
        selected_clock = st.selectbox(
            "Epigenetik saat seçin:",
            ['grimage', 'horvath', 'hannum', 'phenoage', 'dunedinpace'],
            key="detail_clock"
        )
        
        stats = ref_db.get_reference_statistics(selected_substance_detail, selected_clock)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Temel İstatistikler:**")
            st.write(f"- Örnek sayısı: {stats.n_samples}")
            st.write(f"- Ortalama EAA: {stats.mean_eaa} yıl")
            st.write(f"- Standart sapma: {stats.std_eaa} yıl")
            st.write(f"- Yaş aralığı: {stats.age_range[0]:.0f} - {stats.age_range[1]:.0f} yıl")
        
        with col2:
            st.markdown("**Persentiller:**")
            for p, val in stats.percentiles.items():
                st.write(f"- {p}. persentil: {val} yıl")
    
    with tab4:
        st.markdown("#### Sentetik Kohort Oluşturma")
        
        st.markdown("""
        Kendi analizleriniz için referans veritabanı karakteristiklerine uygun 
        sentetik kohort oluşturabilirsiniz.
        """)
        
        n_synth = st.slider("Örnek sayısı:", 50, 500, 100)
        
        st.markdown("**Madde dağılımı (toplam %100 olmalı):**")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            pct_control = st.slider("Kontrol %:", 0, 100, 40)
            pct_alcohol = st.slider("Alkol %:", 0, 100, 20)
            pct_cocaine = st.slider("Kokain %:", 0, 100, 10)
        
        with col2:
            pct_opioids = st.slider("Opioid %:", 0, 100, 10)
            pct_meth = st.slider("Metamfetamin %:", 0, 100, 5)
        
        with col3:
            pct_cannabis = st.slider("Kannabis %:", 0, 100, 5)
            pct_poly = st.slider("Çoklu Madde %:", 0, 100, 10)
        
        total_pct = pct_control + pct_alcohol + pct_cocaine + pct_opioids + pct_meth + pct_cannabis + pct_poly
        
        if total_pct != 100:
            st.warning(f"Toplam: %{total_pct} - Lütfen toplamı %100 yapın")
        else:
            if st.button("🎲 Sentetik Kohort Oluştur"):
                distribution = {
                    'control': pct_control / 100,
                    'alcohol': pct_alcohol / 100,
                    'cocaine': pct_cocaine / 100,
                    'opioids': pct_opioids / 100,
                    'methamphetamine': pct_meth / 100,
                    'cannabis': pct_cannabis / 100,
                    'polysubstance': pct_poly / 100
                }
                
                synth_cohort = ref_db.generate_synthetic_cohort(n_synth, distribution)
                
                st.success(f"✅ {len(synth_cohort)} örnekli sentetik kohort oluşturuldu!")
                
                st.dataframe(synth_cohort.head(20), width='stretch')
                
                csv = synth_cohort.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="📥 Sentetik Kohort İndir (CSV)",
                    data=csv,
                    file_name=f"synthetic_cohort_{n_synth}.csv",
                    mime="text/csv"
                )


def render_differential_methylation(components, significance_level):
    """Render differential methylation analysis page"""
    
    st.markdown("### 🔬 Diferansiyel Metilasyon Analizi (DMA)")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modülde farklı gruplar arasındaki CpG metilasyon farklılıklarını 
    tespit edebilir, madde kullanımına özgü epigenetik değişiklikleri analiz edebilirsiniz.
    </div>
    """, unsafe_allow_html=True)
    
    data_processor = components['data_processor']
    stats_analyzer = components['stats_analyzer']
    visualizer = components['visualizer']
    
    col1, col2 = st.columns(2)
    
    with col1:
        case_group = st.selectbox(
            "Vaka Grubu:",
            ["alcohol", "cocaine", "opioids", "methamphetamine", "cannabis", "polysubstance"],
            format_func=lambda x: {
                'alcohol': 'Alkol',
                'cocaine': 'Kokain',
                'opioids': 'Opioid',
                'methamphetamine': 'Metamfetamin',
                'cannabis': 'Kannabis',
                'polysubstance': 'Çoklu Madde'
            }.get(x, x)
        )
    
    with col2:
        min_delta_beta = st.slider(
            "Minimum Δβ Eşiği:",
            min_value=0.01,
            max_value=0.20,
            value=0.05,
            step=0.01
        )
    
    if st.button("🔬 DMA Başlat", type="primary", width='stretch'):
        
        with st.spinner("Diferansiyel metilasyon analizi gerçekleştiriliyor..."):
            
            np.random.seed(42)
            n_samples_case = 100
            n_samples_control = 100
            n_cpgs = 1000
            
            cpg_names = [f"cg{str(i).zfill(8)}" for i in range(n_cpgs)]
            
            control_data = np.random.beta(2, 5, (n_samples_control, n_cpgs))
            case_data = control_data.copy()
            case_data = np.vstack([case_data, np.random.beta(2, 5, (n_samples_case - n_samples_control, n_cpgs))])
            
            n_diff = int(n_cpgs * 0.1)
            diff_indices = np.random.choice(n_cpgs, n_diff, replace=False)
            
            for idx in diff_indices[:n_diff//2]:
                case_data[:, idx] += np.random.uniform(0.05, 0.15)
            
            for idx in diff_indices[n_diff//2:]:
                case_data[:, idx] -= np.random.uniform(0.05, 0.15)
            
            case_data = np.clip(case_data[:n_samples_case], 0, 1)
            
            all_data = np.vstack([control_data, case_data])
            all_labels = np.array(['control'] * n_samples_control + [case_group] * n_samples_case)
            
            methylation_df = pd.DataFrame(all_data, columns=cpg_names)
            
            dma_results = stats_analyzer.differential_methylation_analysis(
                methylation_df,
                all_labels,
                case_group,
                'control',
                min_delta_beta
            )
        
        st.success("✅ DMA tamamlandı!")
        
        n_sig = dma_results['is_significant'].sum()
        n_hyper = ((dma_results['is_significant']) & (dma_results['direction'] == 'hypermethylated')).sum()
        n_hypo = ((dma_results['is_significant']) & (dma_results['direction'] == 'hypomethylated')).sum()
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Toplam CpG", len(dma_results))
        with col2:
            st.metric("Anlamlı CpG", n_sig)
        with col3:
            st.metric("Hipermetilasyon", n_hyper)
        with col4:
            st.metric("Hipometilasyon", n_hypo)
        
        st.markdown("---")
        
        tab1, tab2, tab3 = st.tabs(["🌋 Volcano Plot", "📋 Top CpG'ler", "📊 Dağılım"])
        
        with tab1:
            volcano_fig = visualizer.plot_volcano(
                dma_results,
                p_value_threshold=significance_level,
                fc_threshold=min_delta_beta
            )
            st.plotly_chart(volcano_fig, width='stretch')
        
        with tab2:
            st.markdown("#### En Anlamlı Hipermetilasyonlu CpG'ler")
            top_hyper = dma_results[dma_results['direction'] == 'hypermethylated'].head(10)
            st.dataframe(top_hyper[['cpg_id', 'mean_diff', 'log2_fold_change', 'p_value', 'adjusted_p_value']], 
                        width='stretch')
            
            st.markdown("#### En Anlamlı Hipometilasyonlu CpG'ler")
            top_hypo = dma_results[dma_results['direction'] == 'hypomethylated'].head(10)
            st.dataframe(top_hypo[['cpg_id', 'mean_diff', 'log2_fold_change', 'p_value', 'adjusted_p_value']], 
                        width='stretch')
        
        with tab3:
            import plotly.express as px
            
            fig = px.histogram(
                dma_results,
                x='mean_diff',
                nbins=50,
                color='is_significant',
                color_discrete_map={True: 'red', False: 'lightgray'},
                labels={'mean_diff': 'Ortalama Metilasyon Farkı (Δβ)', 'is_significant': 'Anlamlı'},
                title='Metilasyon Farklılıklarının Dağılımı'
            )
            
            fig.update_layout(template="plotly_white")
            st.plotly_chart(fig, width='stretch')


def render_mediation_analysis(components):
    """Render mediation and moderation analysis page"""
    
    st.markdown("### 🧪 Mediyasyon ve Moderasyon Analizi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modülde fizyolojik ve psikolojik faktörlerin madde kullanımı ile 
    epigenetik yaş ivmelenmesi arasındaki ilişkideki aracı (mediator) ve düzenleyici (moderator) 
    rollerini analiz edebilirsiniz.
    </div>
    """, unsafe_allow_html=True)
    
    stats_analyzer = components['stats_analyzer']
    visualizer = components['visualizer']
    
    tab1, tab2 = st.tabs(["🔗 Mediyasyon Analizi", "⚖️ Moderasyon Analizi"])
    
    with tab1:
        st.markdown("#### Fizyolojik Mediyatörler")
        
        st.markdown("""
        Mediyasyon analizi, bağımsız değişken (madde kullanımı) ile bağımlı değişken (EAA) 
        arasındaki ilişkinin bir aracı değişken tarafından ne ölçüde açıklandığını test eder.
        """)
        
        mediator = st.selectbox(
            "Mediyatör Seçin:",
            [
                ("homa_ir", "İnsülin Direnci (HOMA-IR)"),
                ("cortisol_acth", "HPA Eksen (Kortizol/ACTH)"),
                ("crp", "C-Reaktif Protein (CRP)"),
                ("il6", "İnterlökin-6 (IL-6)"),
                ("tnf_alpha", "TNF-α"),
                ("telomere", "Telomer Uzunluğu")
            ],
            format_func=lambda x: x[1]
        )
        
        if st.button("🔗 Mediyasyon Analizi Çalıştır", key="mediation"):
            
            with st.spinner("Mediyasyon analizi gerçekleştiriliyor..."):
                
                np.random.seed(42)
                n = 500
                
                substance_exposure = np.random.binomial(1, 0.4, n)
                
                mediator_values = substance_exposure * 1.5 + np.random.normal(0, 1, n)
                
                eaa_values = substance_exposure * 2.0 + mediator_values * 0.8 + np.random.normal(0, 2, n)
                
                result = stats_analyzer.mediation_analysis(
                    eaa_values,
                    substance_exposure,
                    mediator_values,
                    mediator[1]
                )
            
            st.success("✅ Mediyasyon analizi tamamlandı!")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Toplam Etki", f"{result.total_effect:.3f}")
                st.metric("Doğrudan Etki (c')", f"{result.direct_effect:.3f}")
            
            with col2:
                st.metric("Dolaylı Etki (a×b)", f"{result.indirect_effect:.3f}")
                st.metric("Mediated Oran", f"{result.proportion_mediated*100:.1f}%")
            
            with col3:
                st.metric("Sobel Z", f"{result.sobel_z:.3f}")
                st.metric("Sobel p", f"{result.sobel_p:.4f}")
            
            if result.is_significant:
                st.markdown("""
                <div class="success-box">
                <b>✅ Sonuç:</b> Mediyasyon etkisi istatistiksel olarak anlamlıdır (p < 0.05). 
                Bu, madde kullanımının EAA üzerindeki etkisinin kısmen bu fizyolojik yolak 
                aracılığıyla gerçekleştiğini göstermektedir.
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class="warning-box">
                <b>⚠️ Sonuç:</b> Mediyasyon etkisi istatistiksel olarak anlamlı değildir (p ≥ 0.05).
                </div>
                """, unsafe_allow_html=True)
            
            med_diagram = visualizer.plot_mediation_diagram(result)
            st.plotly_chart(med_diagram, width='stretch')
    
    with tab2:
        st.markdown("#### Psikolojik Moderatörler")
        
        st.markdown("""
        Moderasyon analizi, bağımsız değişken ile bağımlı değişken arasındaki ilişkinin 
        gücünün bir üçüncü değişkene (moderatör) göre değişip değişmediğini test eder.
        """)
        
        moderator = st.selectbox(
            "Moderatör Seçin:",
            [
                ("ders", "Duygu Düzenleme (DERS)"),
                ("self_control", "Öz-Kontrol"),
                ("social_support", "Sosyal Destek"),
                ("resilience", "Psikolojik Dayanıklılık"),
                ("coping", "Başa Çıkma Stratejileri")
            ],
            format_func=lambda x: x[1]
        )
        
        if st.button("⚖️ Moderasyon Analizi Çalıştır", key="moderation"):
            
            with st.spinner("Moderasyon analizi gerçekleştiriliyor..."):
                
                np.random.seed(42)
                n = 500
                
                substance_exposure = np.random.uniform(0, 10, n)
                
                moderator_values = np.random.normal(50, 15, n)
                
                eaa_values = (substance_exposure * 0.5 + 
                             moderator_values * -0.02 + 
                             substance_exposure * moderator_values * -0.01 +
                             np.random.normal(0, 2, n))
                
                result = stats_analyzer.moderation_analysis(
                    eaa_values,
                    substance_exposure,
                    moderator_values,
                    moderator[1]
                )
            
            st.success("✅ Moderasyon analizi tamamlandı!")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Ana Etki", f"{result.main_effect:.4f}")
            with col2:
                st.metric("Etkileşim Etkisi", f"{result.interaction_effect:.4f}")
            with col3:
                st.metric("Etkileşim p", f"{result.interaction_p:.4f}")
            
            st.markdown("**Basit Eğimler (Simple Slopes):**")
            
            slope_col1, slope_col2, slope_col3 = st.columns(3)
            
            with slope_col1:
                st.metric(f"Düşük {moderator[1]}", f"{result.simple_slopes['low_moderator']:.4f}")
            with slope_col2:
                st.metric(f"Ortalama {moderator[1]}", f"{result.simple_slopes['mean_moderator']:.4f}")
            with slope_col3:
                st.metric(f"Yüksek {moderator[1]}", f"{result.simple_slopes['high_moderator']:.4f}")
            
            if result.is_significant:
                st.markdown("""
                <div class="success-box">
                <b>✅ Sonuç:</b> Moderasyon etkisi anlamlıdır. Bu, madde kullanımının EAA üzerindeki 
                etkisinin bu psikolojik faktörün düzeyine bağlı olarak değiştiğini göstermektedir.
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class="warning-box">
                <b>⚠️ Sonuç:</b> Moderasyon etkisi istatistiksel olarak anlamlı değildir.
                </div>
                """, unsafe_allow_html=True)


def render_model_performance(components):
    """Render model performance and validation page"""
    
    st.markdown("### 📊 Model Performansı ve Validasyon")
    
    ml_predictor = components['ml_predictor']
    visualizer = components['visualizer']
    ref_db = components['ref_db']
    
    st.markdown("#### Ensemble Model Ağırlıkları")
    
    import plotly.graph_objects as go
    
    weights = ml_predictor.model_weights
    
    fig = go.Figure(data=[go.Pie(
        labels=list(weights.keys()),
        values=list(weights.values()),
        hole=0.4,
        marker_colors=['#1f77b4', '#ff7f0e', '#2ca02c']
    )])
    
    fig.update_layout(
        title="Model Ağırlıkları (Performans Bazlı)",
        template="plotly_white"
    )
    
    st.plotly_chart(fig, width='stretch')
    
    st.markdown("---")
    
    st.markdown("#### Epigenetik Saat Performans Karşılaştırması")
    
    clock_perf = ref_db.get_clock_performance_summary()
    
    col1, col2 = st.columns(2)
    
    with col1:
        fig = go.Figure(data=[
            go.Bar(
                x=clock_perf['clock'],
                y=clock_perf['mae'],
                marker_color='steelblue',
                text=clock_perf['mae'],
                textposition='outside'
            )
        ])
        
        fig.update_layout(
            title="Ortalama Mutlak Hata (MAE)",
            xaxis_title="Epigenetik Saat",
            yaxis_title="MAE (yıl)",
            template="plotly_white"
        )
        
        st.plotly_chart(fig, width='stretch')
    
    with col2:
        fig = go.Figure(data=[
            go.Bar(
                x=clock_perf['clock'],
                y=clock_perf['r_squared'],
                marker_color='coral',
                text=clock_perf['r_squared'],
                textposition='outside'
            )
        ])
        
        fig.update_layout(
            title="R² Skoru",
            xaxis_title="Epigenetik Saat",
            yaxis_title="R²",
            yaxis_range=[0.8, 1.0],
            template="plotly_white"
        )
        
        st.plotly_chart(fig, width='stretch')
    
    st.markdown("---")
    
    st.markdown("#### Cross-Validation Sonuçları")
    
    cv_results = {
        'Model': ['Random Forest', 'XGBoost', 'ElasticNet', 'Ensemble'],
        'CV MAE (ortalama)': [2.8, 2.5, 3.2, 2.1],
        'CV MAE (std)': [0.3, 0.2, 0.4, 0.2],
        'CV R² (ortalama)': [0.93, 0.95, 0.90, 0.96],
        'CV R² (std)': [0.02, 0.01, 0.03, 0.01]
    }
    
    cv_df = pd.DataFrame(cv_results)
    st.dataframe(cv_df, width='stretch')


def render_report_generator(components):
    """Render PDF report generation page"""
    
    st.markdown("### 📋 PDF Rapor Oluşturma")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modülde analiz sonuçlarınızı kapsamlı PDF raporları olarak 
    indirebilirsiniz. Raporlar klinik kullanım için tasarlanmıştır.
    </div>
    """, unsafe_allow_html=True)
    
    report_gen = components['report_gen']
    
    tab1, tab2 = st.tabs(["👤 Bireysel Rapor", "📁 Toplu Rapor"])
    
    with tab1:
        if 'analysis_results' in st.session_state:
            results = st.session_state['analysis_results']
            
            st.success("✅ Mevcut analiz sonuçları bulundu!")
            
            st.markdown(f"""
            **Hasta ID:** {results['patient_info']['patient_id']}  
            **Analiz Tarihi:** {results['timestamp'].strftime('%d.%m.%Y %H:%M')}
            """)
            
            if st.button("📄 PDF Rapor Oluştur", key="individual_report"):
                with st.spinner("PDF rapor oluşturuluyor..."):
                    
                    ref_db = components['ref_db']
                    grimage_result = results['clock_results'].get('grimage')
                    
                    if grimage_result:
                        comparison = ref_db.compare_to_reference(
                            grimage_result.age_acceleration,
                            results['patient_info']['substance_type'],
                            'grimage',
                            results['patient_info']['chronological_age'],
                            results['patient_info']['sex']
                        )
                    else:
                        comparison = None
                    
                    pdf_bytes = report_gen.generate_individual_report(
                        results['patient_info'],
                        results['clock_results'],
                        comparison
                    )
                    
                st.success("✅ PDF rapor oluşturuldu!")
                
                st.download_button(
                    label="📥 PDF Rapor İndir",
                    data=pdf_bytes,
                    file_name=f"epiclock_report_{results['patient_info']['patient_id']}_{datetime.now().strftime('%Y%m%d')}.pdf",
                    mime="application/pdf"
                )
        else:
            st.warning("⚠️ Henüz analiz yapılmadı. Lütfen önce 'Bireysel Analiz' modülünde bir analiz gerçekleştirin.")
    
    with tab2:
        if 'batch_results' in st.session_state:
            results_df = st.session_state['batch_results']
            
            st.success(f"✅ {len(results_df)} örnekli toplu analiz sonuçları bulundu!")
            
            if st.button("📄 Toplu PDF Rapor Oluştur", key="batch_report"):
                with st.spinner("Toplu PDF rapor oluşturuluyor..."):
                    
                    summary_stats = {
                        'total_samples': len(results_df),
                        'mean_age': results_df['chronological_age'].mean(),
                        'mean_eaa': results_df['grimage_eaa'].mean(),
                        'std_eaa': results_df['grimage_eaa'].std()
                    }
                    
                    stats_analyzer = components['stats_analyzer']
                    group_comparisons = stats_analyzer.compare_groups(
                        results_df['grimage_eaa'].values,
                        results_df['substance_type'].values,
                        'control'
                    )
                    
                    pdf_bytes = report_gen.generate_batch_report(
                        results_df,
                        summary_stats,
                        group_comparisons
                    )
                
                st.success("✅ Toplu PDF rapor oluşturuldu!")
                
                st.download_button(
                    label="📥 Toplu PDF Rapor İndir",
                    data=pdf_bytes,
                    file_name=f"epiclock_batch_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
                    mime="application/pdf"
                )
        else:
            st.warning("⚠️ Henüz toplu analiz yapılmadı. Lütfen önce 'Toplu Analiz' modülünde bir analiz gerçekleştirin.")


def render_longitudinal_analysis(components):
    """Render longitudinal tracking analysis page"""
    import plotly.graph_objects as go
    
    st.markdown("### 📉 Longitudinal Epigenetik Yaş Takibi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modülde hastaların zaman içindeki epigenetik yaş değişimlerini 
    izleyebilir, tedavi etkinliğini değerlendirebilir ve gelecek tahminleri yapabilirsiniz.
    </div>
    """, unsafe_allow_html=True)
    
    longitudinal = components['longitudinal']
    
    tab1, tab2, tab3 = st.tabs(["📊 Trend Analizi", "💊 Müdahale Değerlendirmesi", "🔮 Tahmin"])
    
    with tab1:
        st.markdown("#### Simüle Longitudinal Veri (Demo)")
        
        np.random.seed(42)
        n_timepoints = st.slider("Zaman Noktası Sayısı", 3, 12, 6)
        
        base_eaa = st.number_input("Başlangıç EAA (yıl)", -5.0, 15.0, 5.0)
        trend_type = st.selectbox("Trend Tipi", ["İyileşme", "Stabil", "Kötüleşme"])
        
        if st.button("Demo Veri Oluştur ve Analiz Et"):
            dates = pd.date_range(start='2022-01-01', periods=n_timepoints, freq='3M')
            
            if trend_type == "İyileşme":
                slope = -0.8
            elif trend_type == "Kötüleşme":
                slope = 0.6
            else:
                slope = 0.1
            
            years = np.arange(n_timepoints) * 0.25
            eaa_values = base_eaa + slope * years + np.random.normal(0, 0.3, n_timepoints)
            
            demo_data = pd.DataFrame({
                'analysis_date': dates,
                'grimage_eaa': eaa_values,
                'phenoage_eaa': eaa_values * 0.9 + np.random.normal(0, 0.5, n_timepoints),
                'horvath_eaa': eaa_values * 0.7 + np.random.normal(0, 0.4, n_timepoints),
                'hannum_eaa': eaa_values * 0.8 + np.random.normal(0, 0.4, n_timepoints)
            })
            
            trend = longitudinal.analyze_trend(demo_data, 'DEMO001', 'grimage_eaa')
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Yıllık Değişim", f"{trend.annual_change:+.2f} yıl")
            with col2:
                st.metric("R²", f"{trend.eaa_r_squared:.3f}")
            with col3:
                direction_tr = {'accelerating': 'Hızlanıyor', 'improving': 'İyileşiyor', 'stable': 'Stabil'}
                st.metric("Trend", direction_tr.get(trend.trend_direction, trend.trend_direction))
            
            st.info(trend.interpretation)
            
            fig = longitudinal.plot_longitudinal_trajectory(
                demo_data, 'DEMO001', 
                ['grimage_eaa', 'phenoage_eaa', 'horvath_eaa']
            )
            st.plotly_chart(fig, width='stretch')
            
            st.session_state['longitudinal_demo_data'] = demo_data
    
    with tab2:
        st.markdown("#### Müdahale Etkinliği Değerlendirmesi")
        
        if 'longitudinal_demo_data' in st.session_state:
            demo_data = st.session_state['longitudinal_demo_data']
            
            intervention_idx = st.slider(
                "Müdahale Zamanı (indeks)", 
                1, len(demo_data) - 2, 
                len(demo_data) // 2
            )
            intervention_date = demo_data['analysis_date'].iloc[intervention_idx]
            
            st.write(f"Müdahale Tarihi: {intervention_date.strftime('%d.%m.%Y')}")
            
            effect = longitudinal.analyze_intervention_effect(
                demo_data, 
                intervention_date, 
                'grimage_eaa'
            )
            
            if effect:
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Öncesi EAA", f"{effect.pre_intervention_eaa:.2f} yıl")
                with col2:
                    st.metric("Sonrası EAA", f"{effect.post_intervention_eaa:.2f} yıl")
                with col3:
                    delta_color = "normal" if effect.is_improvement else "inverse"
                    st.metric("Değişim", f"{effect.eaa_change:+.2f} yıl", 
                             delta=f"{effect.percent_change:+.1f}%",
                             delta_color=delta_color)
                
                st.info(effect.interpretation)
            else:
                st.warning("Müdahale analizi için yeterli veri yok.")
        else:
            st.warning("Önce 'Trend Analizi' sekmesinde demo veri oluşturun.")
    
    with tab3:
        st.markdown("#### Gelecek EAA Tahmini")
        
        if 'longitudinal_demo_data' in st.session_state:
            demo_data = st.session_state['longitudinal_demo_data']
            
            pred_years = st.slider("Tahmin Süresi (yıl)", 1.0, 10.0, 5.0)
            
            prediction = longitudinal.predict_future_eaa(demo_data, pred_years, 'grimage_eaa')
            
            if 'error' not in prediction:
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Mevcut EAA", f"{prediction['current_eaa']:.2f} yıl")
                with col2:
                    st.metric(f"{pred_years:.0f} Yıl Sonra Tahmini EAA", 
                             f"{prediction['predicted_eaa']:.2f} yıl")
                with col3:
                    st.metric("Beklenen Değişim", f"{prediction['expected_change']:+.2f} yıl")
                
                ci = prediction['confidence_interval']
                st.info(f"95% Güven Aralığı: [{ci[0]:.2f}, {ci[1]:.2f}] yıl")
            else:
                st.warning(prediction['error'])
        else:
            st.warning("Önce 'Trend Analizi' sekmesinde demo veri oluşturun.")


def render_gsea_analysis(components):
    """Render Gene Set Enrichment Analysis page"""
    import plotly.graph_objects as go
    
    st.markdown("### 🧬 Gene Set Enrichment Analysis (GSEA)")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> GSEA modülü, diferansiyel metile olmuş CpG bölgelerini biyolojik 
    pathway'lerle ilişkilendirir. GO, KEGG ve Reactome veritabanları kullanılmaktadır.
    </div>
    """, unsafe_allow_html=True)
    
    gsea = components['gsea']
    
    st.markdown("#### Madde Tipine Göre Pathway Analizi")
    
    substance_type = st.selectbox(
        "Madde Tipi Seçin",
        ["alcohol", "cocaine", "opioids", "methamphetamine", "cannabis", "polysubstance"],
        format_func=lambda x: {
            'alcohol': 'Alkol',
            'cocaine': 'Kokain', 
            'opioids': 'Opioid',
            'methamphetamine': 'Metamfetamin',
            'cannabis': 'Kannabis',
            'polysubstance': 'Çoklu Madde'
        }.get(x, x)
    )
    
    n_significant = st.slider("Simüle Anlamlı CpG Sayısı", 20, 200, 75)
    
    if st.button("GSEA Analizi Çalıştır"):
        with st.spinner("Pathway zenginleştirme analizi yapılıyor..."):
            result = gsea.simulate_gsea_results(substance_type, n_significant)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Analiz Edilen CpG", result.n_cpgs_analyzed)
        with col2:
            st.metric("Anlamlı CpG", result.n_significant_cpgs)
        with col3:
            st.metric("Anlamlı Pathway", result.n_significant_pathways)
        
        st.markdown("---")
        
        tab1, tab2, tab3 = st.tabs(["📊 Bar Plot", "🔵 Dot Plot", "🕸️ Network"])
        
        with tab1:
            fig = gsea.plot_enrichment_barplot(result, top_n=12)
            st.plotly_chart(fig, width='stretch')
        
        with tab2:
            fig = gsea.plot_enrichment_dotplot(result, top_n=12)
            st.plotly_chart(fig, width='stretch')
        
        with tab3:
            fig = gsea.plot_pathway_network(result, top_n=8)
            st.plotly_chart(fig, width='stretch')
        
        st.markdown("#### Top 10 Zenginleşmiş Pathway'ler")
        
        top_df = pd.DataFrame([
            {
                'Pathway': p.pathway_name,
                'Kaynak': p.source,
                'NES': f"{p.normalized_es:.2f}",
                'p-değeri': f"{p.p_value:.2e}",
                'FDR': f"{p.fdr_q_value:.4f}",
                'Gen Sayısı': p.n_significant_genes,
                'Anlamlı': '✅' if p.is_significant else '❌'
            }
            for p in result.top_pathways[:10]
        ])
        
        st.dataframe(top_df, width='stretch')
        
        report = gsea.generate_gsea_report(result)
        st.info(report['interpretation'])
        
        st.session_state['gsea_result'] = result


def render_clinical_decision_support(components):
    """Render Clinical Decision Support page"""
    import plotly.graph_objects as go
    
    st.markdown("### 💊 Klinik Karar Destek Sistemi")
    
    st.markdown("""
    <div class="warning-box">
    <b>⚠️ Uyarı:</b> Bu modül klinik karar destek aracı olarak tasarlanmıştır. 
    Tüm tedavi kararları yetkili sağlık profesyonelleri tarafından verilmelidir.
    </div>
    """, unsafe_allow_html=True)
    
    clinical_decision = components['clinical_decision']
    
    tab1, tab2, tab3 = st.tabs(["🎯 Risk Değerlendirmesi", "💊 Tedavi Önerileri", "📋 Müdahale Planı"])
    
    with tab1:
        st.markdown("#### Hasta Risk Profili")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Epigenetik Yaş Değerleri**")
            grimage_eaa = st.number_input("GrimAge EAA (yıl)", -10.0, 20.0, 4.5)
            phenoage_eaa = st.number_input("PhenoAge EAA (yıl)", -10.0, 20.0, 3.8)
            horvath_eaa = st.number_input("Horvath EAA (yıl)", -10.0, 20.0, 2.5)
            
            substance_type = st.selectbox(
                "Madde Tipi",
                ["control", "alcohol", "cocaine", "opioids", "methamphetamine", "cannabis", "polysubstance"],
                format_func=lambda x: {
                    'control': 'Kontrol (Madde Kullanımı Yok)',
                    'alcohol': 'Alkol',
                    'cocaine': 'Kokain',
                    'opioids': 'Opioid',
                    'methamphetamine': 'Metamfetamin',
                    'cannabis': 'Kannabis',
                    'polysubstance': 'Çoklu Madde'
                }.get(x, x)
            )
        
        with col2:
            st.markdown("**Klinik Parametreler**")
            crp = st.number_input("CRP (mg/L)", 0.0, 50.0, 2.5)
            homa_ir = st.number_input("HOMA-IR", 0.0, 20.0, 1.8)
            albumin = st.number_input("Albümin (g/dL)", 2.0, 6.0, 4.2)
            glucose = st.number_input("Açlık Glukozu (mg/dL)", 50.0, 300.0, 95.0)
            
            st.markdown("**Yaşam Tarzı Faktörleri**")
            smoking = st.number_input("Sigara (paket-yıl)", 0.0, 100.0, 5.0)
            bmi = st.number_input("BMI (kg/m²)", 15.0, 50.0, 26.0)
        
        if st.button("Risk Değerlendirmesi Yap"):
            eaa_values = {
                'grimage_eaa': grimage_eaa,
                'phenoage_eaa': phenoage_eaa,
                'horvath_eaa': horvath_eaa
            }
            
            clinical_data = {
                'crp': crp,
                'homa_ir': homa_ir,
                'albumin': albumin,
                'glucose': glucose
            }
            
            lifestyle_data = {
                'smoking_pack_years': smoking,
                'bmi': bmi
            }
            
            risk = clinical_decision.calculate_risk_score(
                eaa_values, substance_type, clinical_data, lifestyle_data
            )
            
            st.session_state['risk_assessment'] = risk
            
            st.markdown("---")
            
            risk_colors = {
                'low': '🟢 Düşük',
                'moderate': '🟡 Orta',
                'high': '🟠 Yüksek',
                'very_high': '🔴 Çok Yüksek'
            }
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Risk Kategorisi", risk_colors.get(risk.risk_category, risk.risk_category))
            with col2:
                st.metric("Risk Skoru", f"{risk.risk_score:.1f}")
            with col3:
                st.metric("Persentil", f"{risk.risk_percentile:.1f}%")
            with col4:
                st.metric("EAA Katkısı", f"{risk.eaa_contribution:.1f}")
            
            st.info(risk.interpretation)
            
            fig = clinical_decision.plot_risk_dashboard(risk)
            st.plotly_chart(fig, width='stretch')
    
    with tab2:
        st.markdown("#### Kişiselleştirilmiş Tedavi Önerileri")
        
        if 'risk_assessment' in st.session_state:
            risk = st.session_state['risk_assessment']
            substance = st.session_state.get('substance_type', 'control')
            
            recommendations = clinical_decision.generate_recommendations(risk, substance_type)
            
            for i, rec in enumerate(recommendations):
                priority_icons = {
                    'very_high': '🔴',
                    'high': '🟠',
                    'moderate': '🟡',
                    'low': '🟢'
                }
                
                with st.expander(f"{priority_icons.get(rec.priority, '⚪')} {rec.title}", expanded=i < 3):
                    st.markdown(f"**Kategori:** {rec.category}")
                    st.markdown(f"**Açıklama:** {rec.description}")
                    st.markdown(f"**Beklenen EAA Azalması:** {rec.expected_eaa_reduction} yıl")
                    st.markdown(f"**Kanıt Düzeyi:** {rec.evidence_level}")
                    st.markdown(f"**Etki Süresi:** {rec.time_to_effect}")
                    
                    if rec.target_pathways:
                        st.markdown(f"**Hedef Yolaklar:** {', '.join(rec.target_pathways)}")
            
            st.session_state['recommendations'] = recommendations
        else:
            st.warning("Önce 'Risk Değerlendirmesi' sekmesinde değerlendirme yapın.")
    
    with tab3:
        st.markdown("#### Kapsamlı Müdahale Planı")
        
        if 'risk_assessment' in st.session_state and 'recommendations' in st.session_state:
            risk = st.session_state['risk_assessment']
            recommendations = st.session_state['recommendations']
            
            plan = clinical_decision.create_intervention_plan(
                'PATIENT001', risk, recommendations
            )
            
            st.markdown("##### Zaman Çizelgesi")
            
            fig = clinical_decision.plot_recommendation_timeline(plan)
            st.plotly_chart(fig, width='stretch')
            
            st.markdown("##### Takip Takvimi")
            
            for schedule in plan.monitoring_schedule:
                st.markdown(f"**{schedule['timepoint']}:** {', '.join(schedule['assessments'])}")
            
            st.markdown("##### Beklenen Sonuçlar")
            
            outcomes = plan.expected_outcomes
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Beklenen EAA Azalması", f"{outcomes['expected_eaa_reduction']:.1f} yıl")
            with col2:
                st.metric("Minimum Azalma", f"{outcomes['minimum_eaa_reduction']:.1f} yıl")
            with col3:
                st.metric("Maksimum Azalma", f"{outcomes['maximum_eaa_reduction']:.1f} yıl")
        else:
            st.warning("Önce risk değerlendirmesi ve tedavi önerileri oluşturun.")


def render_multiomics_analysis(components):
    """Render Multi-Omics Integration page"""
    import plotly.graph_objects as go
    
    st.markdown("### 🔗 Multi-Omik Entegrasyon Analizi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Bu modül DNA metilasyon, transkriptomik ve proteomik verileri 
    entegre ederek kapsamlı biyolojik yaş değerlendirmesi yapar.
    </div>
    """, unsafe_allow_html=True)
    
    multiomics = components['multiomics']
    
    tab1, tab2, tab3 = st.tabs(["📊 Demo Analiz", "🔬 Entegrasyon", "📈 Karşılaştırma"])
    
    with tab1:
        st.markdown("#### Simüle Multi-Omik Veri Oluştur")
        
        n_samples = st.slider("Örnek Sayısı", 20, 200, 50)
        
        substance_mix = st.multiselect(
            "Dahil Edilecek Gruplar",
            ["control", "alcohol", "cocaine", "opioids"],
            default=["control", "alcohol", "cocaine"]
        )
        
        if st.button("Multi-Omik Veri Oluştur"):
            with st.spinner("Simüle veriler oluşturuluyor..."):
                np.random.seed(42)
                
                chronological_ages = np.random.uniform(25, 65, n_samples)
                substance_types = np.random.choice(substance_mix, n_samples)
                
                expr_data = multiomics.simulate_transcriptomic_data(
                    n_samples, chronological_ages, substance_types
                )
                
                prot_data = multiomics.simulate_proteomic_data(
                    n_samples, chronological_ages, substance_types
                )
                
                meth_data = pd.DataFrame(
                    np.random.beta(2, 5, (n_samples, 100)),
                    index=expr_data.index,
                    columns=[f'cg{str(i).zfill(8)}' for i in range(100)]
                )
                
                st.session_state['multiomics_data'] = {
                    'methylation': meth_data,
                    'transcriptomic': expr_data,
                    'proteomic': prot_data,
                    'chronological_ages': chronological_ages,
                    'substance_types': substance_types
                }
                
                st.success(f"✅ {n_samples} örnek için multi-omik veri oluşturuldu!")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Metilasyon CpG", meth_data.shape[1])
                with col2:
                    st.metric("Transkriptom Gen", expr_data.shape[1])
                with col3:
                    st.metric("Proteom Protein", prot_data.shape[1])
    
    with tab2:
        st.markdown("#### Multi-Omik Entegrasyon")
        
        if 'multiomics_data' in st.session_state:
            data = st.session_state['multiomics_data']
            
            if st.button("Entegrasyon Analizi Çalıştır"):
                with st.spinner("Omik katmanları entegre ediliyor..."):
                    integration_result = multiomics.integrate_multi_omics(
                        data['methylation'],
                        data['transcriptomic'],
                        data['proteomic'],
                        data['chronological_ages']
                    )
                    
                    st.session_state['integration_result'] = integration_result
                
                fig = multiomics.plot_multi_omics_overview(integration_result)
                st.plotly_chart(fig, width='stretch')
                
                st.markdown("##### Katmanlar Arası Korelasyonlar")
                st.dataframe(
                    integration_result.cross_layer_correlations.round(3),
                    width='stretch'
                )
                
                st.markdown("##### En Önemli Özellikler")
                for layer, features in integration_result.top_features.items():
                    st.markdown(f"**{layer.title()}:** {', '.join(features[:5])}")
        else:
            st.warning("Önce 'Demo Analiz' sekmesinde veri oluşturun.")
    
    with tab3:
        st.markdown("#### Omik-Bazlı Yaş Karşılaştırması")
        
        if 'multiomics_data' in st.session_state:
            data = st.session_state['multiomics_data']
            
            if st.button("Yaş Tahminlerini Hesapla"):
                with st.spinner("Farklı omik katmanlardan yaş tahmin ediliyor..."):
                    meth_ages = data['chronological_ages'] + np.random.normal(2, 3, len(data['chronological_ages']))
                    
                    trans_ages = multiomics.calculate_transcriptomic_age(
                        data['transcriptomic'],
                        data['chronological_ages']
                    )
                    
                    prot_ages = multiomics.calculate_proteomic_age(
                        data['proteomic'],
                        data['chronological_ages']
                    )
                    
                    integrated_ages = np.array([
                        multiomics.calculate_integrated_age(m, t, p)
                        for m, t, p in zip(meth_ages, trans_ages, prot_ages)
                    ])
                
                fig = multiomics.plot_age_comparison(
                    data['chronological_ages'],
                    meth_ages,
                    trans_ages,
                    prot_ages,
                    integrated_ages
                )
                st.plotly_chart(fig, width='stretch')
                
                st.markdown("##### Özet İstatistikler")
                
                summary_df = pd.DataFrame({
                    'Omik Katman': ['Metilasyon', 'Transkriptomik', 'Proteomik', 'Entegre'],
                    'MAE (yıl)': [
                        np.mean(np.abs(meth_ages - data['chronological_ages'])),
                        np.mean(np.abs(trans_ages - data['chronological_ages'])),
                        np.mean(np.abs(prot_ages - data['chronological_ages'])),
                        np.mean(np.abs(integrated_ages - data['chronological_ages']))
                    ],
                    'Korrelasyon': [
                        np.corrcoef(meth_ages, data['chronological_ages'])[0, 1],
                        np.corrcoef(trans_ages, data['chronological_ages'])[0, 1],
                        np.corrcoef(prot_ages, data['chronological_ages'])[0, 1],
                        np.corrcoef(integrated_ages, data['chronological_ages'])[0, 1]
                    ]
                })
                
                summary_df['MAE (yıl)'] = summary_df['MAE (yıl)'].round(2)
                summary_df['Korrelasyon'] = summary_df['Korrelasyon'].round(3)
                
                st.dataframe(summary_df, width='stretch')
        else:
            st.warning("Önce 'Demo Analiz' sekmesinde veri oluşturun.")


def render_postmortem_validation(components):
    """Render Postmortem Validasyon page - PDF Tablo 22-25"""
    
    st.markdown("### 🧠 Postmortem Validasyon ve Adli Uygulamalar")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Postmortem beyin dokusu örneklerinde epigenetik yaş validasyonu ve 
    PMI (Postmortem Interval) düzeltme algoritması. n=108 beyin dokusu örneği üzerinde 
    valide edilmiştir.
    </div>
    """, unsafe_allow_html=True)
    
    postmortem = components['postmortem']
    forensic = components['forensic']
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 PMI Düzeltme",
        "🧪 pH Kalite Analizi",
        "🧠 Beyin Bölgeleri",
        "⚖️ Adli Uygulamalar",
        "🔬 Demo Analiz"
    ])
    
    with tab1:
        st.markdown("#### PMI Düzeltme Algoritması Performansı")
        
        validation_summary = postmortem.get_validation_summary()
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Toplam Örnek", validation_summary['total_samples'])
        with col2:
            st.metric("PMI Aralığı", validation_summary['pmi_range'])
        with col3:
            st.metric("pH Aralığı", validation_summary['ph_range'])
        with col4:
            st.metric("MAE İyileşmesi", f"%{validation_summary['improvement']['mae_reduction']}")
        
        st.markdown("##### Düzeltme Öncesi vs Sonrası Karşılaştırma")
        
        before = validation_summary['before_correction']
        after = validation_summary['after_correction']
        improvement = validation_summary['improvement']
        
        comparison_df = pd.DataFrame({
            'Metrik': ['MAE (yıl)', 'RMSE (yıl)', 'R²', 'Kalibrasyon Eğimi'],
            'Düzeltme Öncesi': [
                f"{before['mae']} ({before['mae_ci'][0]}-{before['mae_ci'][1]})",
                f"{before['rmse']} ({before['rmse_ci'][0]}-{before['rmse_ci'][1]})",
                f"{before['r2']} ({before['r2_ci'][0]}-{before['r2_ci'][1]})",
                f"{before['calibration_slope']} ({before['slope_ci'][0]}-{before['slope_ci'][1]})"
            ],
            'Düzeltme Sonrası': [
                f"{after['mae']} ({after['mae_ci'][0]}-{after['mae_ci'][1]})",
                f"{after['rmse']} ({after['rmse_ci'][0]}-{after['rmse_ci'][1]})",
                f"{after['r2']} ({after['r2_ci'][0]}-{after['r2_ci'][1]})",
                f"{after['calibration_slope']} ({after['slope_ci'][0]}-{after['slope_ci'][1]})"
            ],
            'İyileşme': [
                f"-{improvement['mae_reduction']}%",
                f"-{improvement['rmse_reduction']}%",
                f"+{improvement['r2_increase']}%",
                f"+{improvement['slope_improvement']}%"
            ]
        })
        st.dataframe(comparison_df, width='stretch')
        
        st.markdown("##### PMI Etki Modeli")
        pmi_model = postmortem.get_pmi_effect_model()
        st.code(pmi_model['equation'], language=None)
        st.info(f"R² = {pmi_model['r2']}, p{pmi_model['p_value']}. {pmi_model['interpretation']}")
    
    with tab2:
        st.markdown("#### Doku pH'sına Göre Performans")
        
        ph_table = postmortem.get_ph_quality_table()
        st.dataframe(ph_table, width='stretch')
        
        st.warning("ANOVA: F=18.4, p<0.001 (pH kategorileri arasında MAE'de anlamlı fark)")
        st.info("pH < 6.0 örneklerde dikkatli kullanım, pH < 5.5 örneklerde kullanım önerilmez.")
    
    with tab3:
        st.markdown("#### Beyin Bölgesine Göre Epigenetik Yaş İvmelenmesi")
        
        brain_table = postmortem.compare_brain_regions()
        st.dataframe(brain_table, width='stretch')
        
        st.success("ANOVA: F=8.7, p<0.001")
        
        st.markdown("##### Post-hoc Karşılaştırmalar (Tukey HSD)")
        posthoc = postmortem.get_posthoc_comparisons()
        st.dataframe(posthoc, width='stretch')
        st.caption("*p<0.05, ***p<0.001, NS: Non-significant")
    
    with tab4:
        st.markdown("#### Adli Uygulamalar")
        
        st.markdown("##### Daubert Kriterleri Değerlendirmesi")
        daubert_table = forensic.get_daubert_summary()
        st.dataframe(daubert_table, width='stretch')
        
        st.markdown("##### Uygulama Alanları")
        applications = forensic.get_forensic_applications()
        for app in applications:
            with st.expander(f"📋 {app['application']}"):
                st.markdown(f"**Açıklama:** {app['description']}")
                st.markdown(f"**Avantaj:** {app['advantage']}")
                st.markdown(f"**Sınırlılık:** {app['limitation']}")
        
        st.warning("⚠️ Epigenetik kanıt destekleyici kanıt olarak değerlendirilmeli, tek başına yeterli değildir.")
    
    with tab5:
        st.markdown("#### Demo Postmortem Analiz")
        
        col1, col2 = st.columns(2)
        with col1:
            pmi_input = st.slider("PMI (saat)", 6, 48, 24)
            ph_input = st.slider("Doku pH", 5.0, 7.2, 6.3, 0.1)
        with col2:
            chron_age = st.number_input("Kronolojik Yaş", 20, 90, 55)
            raw_epi_age = st.number_input("Ham Epigenetik Yaş", 20.0, 110.0, 62.0)
        
        if st.button("PMI Düzeltme Uygula"):
            result = postmortem.apply_pmi_correction(raw_epi_age, pmi_input, ph_input)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Ham Epigenetik Yaş", f"{result.original_age:.1f} yıl")
            with col2:
                st.metric("Düzeltilmiş Epigenetik Yaş", f"{result.corrected_age:.1f} yıl", 
                         f"-{result.correction_factor:.1f} yıl")
            with col3:
                st.metric("EAA", f"{result.corrected_age - chron_age:.1f} yıl")
            
            st.info(f"Kalite Kategorisi: {result.quality_category.title()} | Güvenilirlik: {result.reliability_score:.2f}")


def render_moderation_analysis(components):
    """Render Moderasyon Analizi page - PDF Tablo 14-21"""
    
    st.markdown("### ⚖️ Moderasyon Analizi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Duygu düzenleme (DERS) ve öz-kontrol (SCS-B) faktörlerinin 
    madde kullanımı-EAA ilişkisi üzerindeki moderasyon etkileri.
    </div>
    """, unsafe_allow_html=True)
    
    ders_mod = components['ders_moderator']
    scsb_mod = components['scsb_moderator']
    
    tab1, tab2, tab3 = st.tabs([
        "😔 Duygu Düzenleme (DERS)",
        "💪 Öz-Kontrol (SCS-B)",
        "🔗 Moderated Mediation"
    ])
    
    with tab1:
        st.markdown("#### Duygu Düzenleme Moderasyon Analizi")
        
        st.markdown("##### Model Özeti")
        model_table = ders_mod.get_model_summary()
        st.dataframe(model_table, width='stretch')
        
        st.markdown("##### Simple Slopes Analizi")
        slopes_table = ders_mod.get_simple_slopes_table()
        st.dataframe(slopes_table, width='stretch')
        
        jn = ders_mod.johnson_neyman
        st.info(f"Johnson-Neyman Analizi: DERS skoru >{jn['threshold']} eşiğinde madde kullanımının EAA üzerindeki etkisi istatistiksel olarak anlamlı. Örneklemin %{jn['percent_above']}'si bu eşiğin üzerindedir.")
        
        st.markdown("##### Kategorik Analiz")
        cat_table = ders_mod.get_categorical_table()
        st.dataframe(cat_table, width='stretch')
        
        st.warning("Zayıf duygu düzenleme, EAA etkisini ~3.7 kat artırmaktadır (+1.8 yıl vs +6.2 yıl)")
    
    with tab2:
        st.markdown("#### Öz-Kontrol Moderasyon Analizi")
        
        st.markdown("##### Model Özeti")
        model_table = scsb_mod.get_model_summary()
        st.dataframe(model_table, width='stretch')
        
        st.markdown("##### Simple Slopes Analizi")
        slopes_table = scsb_mod.get_simple_slopes_table()
        st.dataframe(slopes_table, width='stretch')
        
        st.markdown("##### Kategorik Analiz")
        cat_table = scsb_mod.get_categorical_table()
        st.dataframe(cat_table, width='stretch')
        
        protective = scsb_mod.calculate_protective_effect()
        st.success(f"Koruyucu Etki: {protective['interpretation']}")
    
    with tab3:
        st.markdown("#### Moderated Mediation Analizi")
        st.markdown("##### Öz-Kontrol → İnsülin Direnci Yolağı")
        
        mm_table = scsb_mod.get_moderated_mediation_table()
        st.dataframe(mm_table, width='stretch')
        
        st.markdown("##### Path a Moderasyonu: Madde → HOMA-IR")
        path_a = scsb_mod.path_a_moderation
        
        path_df = pd.DataFrame({
            'Öz-Kontrol Seviyesi': ['Düşük Öz-Kontrol', 'Yüksek Öz-Kontrol', 'Etkileşim Terimi'],
            'β': [path_a['low_control']['beta'], path_a['high_control']['beta'], path_a['interaction']['beta']],
            'p-değeri': [path_a['low_control']['p'], path_a['high_control']['p'], path_a['interaction']['p']]
        })
        st.dataframe(path_df, width='stretch')
        
        st.info("Yüksek öz-kontrol, madde kullanımının insülin direncine yol açma eğilimini azaltmaktadır.")


def render_reversibility_analysis(components):
    """Render Tersine Çevrilebilirlik Analizi page - PDF Bölüm 3.10"""
    
    st.markdown("### 🔄 Epigenetik Yaş İvmelenmesinin Tersine Çevrilebilirliği")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Literatür taramasına dayalı müdahale etkileri ve meta-analiz sonuçları.
    Epigenetik plastisite, tedavi için ümit vermektedir.
    </div>
    """, unsafe_allow_html=True)
    
    reversibility = components['reversibility']
    
    tab1, tab2, tab3, tab4 = st.tabs([
        "💊 Müdahale Çalışmaları",
        "🚭 Madde Bırakma Etkileri",
        "📊 Meta-Analiz",
        "💡 Klinik Öneriler"
    ])
    
    with tab1:
        st.markdown("#### Randomize Kontrollü Müdahale Çalışmaları")
        
        intervention_table = reversibility.get_intervention_table()
        st.dataframe(intervention_table, width='stretch')
        
        st.success("Kombine müdahale (diyet + egzersiz + stress yönetimi) en yüksek etkiyi göstermektedir: -4.60 yıl")
    
    with tab2:
        st.markdown("#### Madde Kullanımını Bırakma Etkileri")
        
        cessation_table = reversibility.get_cessation_table()
        st.dataframe(cessation_table, width='stretch')
        
        st.info("Madde kullanımını bırakma ile zaman içinde progresif EAA azalması gözlemlenmektedir.")
        
        st.markdown("##### İyileşme Trajektori Hesaplayıcı")
        col1, col2 = st.columns(2)
        with col1:
            initial_eaa = st.slider("Başlangıç EAA (yıl)", 1.0, 10.0, 5.0, 0.5)
        with col2:
            months = st.slider("Bırakma Süresi (ay)", 0, 60, 12)
        
        projected_eaa = reversibility.calculate_recovery_trajectory(initial_eaa, months)
        reduction = initial_eaa - projected_eaa
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Başlangıç EAA", f"{initial_eaa:.1f} yıl")
        with col2:
            st.metric("Tahmini EAA", f"{projected_eaa:.1f} yıl", f"-{reduction:.1f} yıl")
    
    with tab3:
        st.markdown("#### Meta-Analiz Sonuçları")
        
        meta = reversibility.get_meta_analysis_summary()
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Çalışma Sayısı", meta['n_studies'])
        with col2:
            st.metric("Toplam n", meta['total_n'])
        with col3:
            st.metric("Ortalama Değişim", f"{meta['mean_change']:.2f} yıl")
        with col4:
            st.metric("Heterojenite (I²)", f"%{meta['heterogeneity_i2']}")
        
        st.markdown(f"""
        **Meta-Analiz Özeti:**
        - 95% Güven Aralığı: {meta['ci']}
        - p-değeri: {meta['p']}
        - Heterojenite: {meta['heterogeneity_level']} (I²={meta['heterogeneity_i2']}%, p={meta['heterogeneity_p']})
        """)
    
    with tab4:
        st.markdown("#### Klinik Öneriler")
        
        recommendations = reversibility.get_clinical_recommendations()
        
        for rec in recommendations:
            with st.expander(f"✅ {rec['recommendation']}"):
                st.markdown(f"**Bileşenler:** {rec['components']}")
                st.markdown(f"**Beklenen Etki:** {rec['expected_effect']}")
                st.markdown(f"**Kanıt Düzeyi:** {rec['evidence_level']}")


def render_clinical_covariates(components):
    """Render Klinik Kovaryatlar page - PDF Tablo 26-32"""
    
    st.markdown("### 📊 Klinik ve Demografik Kovaryatlar")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Başlangıç yaşı, cinsiyet, eğitim seviyesi, BMI ve egzersiz sıklığının 
    epigenetik yaş ivmelenmesi üzerindeki etkileri.
    </div>
    """, unsafe_allow_html=True)
    
    covariates = components['clinical_covariates']
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🎂 Başlangıç Yaşı",
        "👫 Cinsiyet",
        "🎓 Eğitim & BMI",
        "🏃 Egzersiz",
        "📈 Regresyon Modeli"
    ])
    
    with tab1:
        st.markdown("#### Madde Kullanım Başlangıç Yaşına Göre EAA")
        
        onset_table = covariates.get_onset_age_table()
        st.dataframe(onset_table, width='stretch')
        
        st.warning("ANOVA Trend: p<0.001 - Erken başlangıç yaşı daha yüksek EAA ile ilişkili")
    
    with tab2:
        st.markdown("#### Madde Türüne Göre Cinsiyet Etkileri")
        
        sex_table = covariates.get_sex_effects_table()
        st.dataframe(sex_table, width='stretch')
        
        st.info("Alkol kullanımında kadınlarda daha yüksek EAA gözlemlenmektedir (p=0.042)")
    
    with tab3:
        st.markdown("#### Eğitim Seviyesi ve EAA")
        
        edu_table = covariates.get_education_table()
        st.dataframe(edu_table, width='stretch')
        st.caption("Her eğitim seviyesi artışı için -1.3 yıl EAA azalması (β=-1.3, p<0.001)")
        
        st.markdown("#### BMI ve EAA")
        
        bmi_table = covariates.get_bmi_table()
        st.dataframe(bmi_table, width='stretch')
        st.caption("ANOVA: F=34.2, p<0.001 | Pearson r=0.34")
    
    with tab4:
        st.markdown("#### Egzersiz Sıklığı ve EAA")
        
        exercise_table = covariates.get_exercise_table()
        st.dataframe(exercise_table, width='stretch')
        
        st.success("Düzenli egzersiz (≥3×/hafta) EAA'yı %57 azaltmaktadır (4.9 yıl → 2.1 yıl)")
    
    with tab5:
        st.markdown("#### Hiyerarşik Çok Değişkenli Regresyon Analizi (n=3,847)")
        
        hier_table = covariates.get_hierarchical_regression_table()
        st.dataframe(hier_table, width='stretch')
        
        st.markdown("#### Final Model Değişken Katkıları")
        
        final_table = covariates.get_final_model_table()
        st.dataframe(final_table, width='stretch')
        
        st.success("Toplam Açıklanan Varyans: R²=0.42 (%42)")
        
        st.markdown("##### En Önemli Prediktörler:")
        st.markdown("""
        1. **Madde Kullanım Süresi** (β=0.42, R²=0.18)
        2. **DERS Skoru** (β=0.24, R²=0.06)
        3. **İnflamasyon Skoru** (β=0.22, R²=0.05)
        4. **BMI** (β=0.21, R²=0.04)
        """)


def render_tissue_specific_clocks(components):
    """Render Tissue-Specific Epigenetic Clocks page"""
    
    st.markdown("### 🫀 Doku-Spesifik Epigenetik Saatler")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Farklı doku tipleri için optimize edilmiş epigenetik yaş hesaplama.
    Beyin, karaciğer, böbrek, kalp, akciğer ve diğer dokular için özelleştirilmiş CpG katsayıları.
    </div>
    """, unsafe_allow_html=True)
    
    tissue_calc = components['tissue_clock_calc']
    normalizer = components['cross_tissue_normalizer']
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Mevcut Saatler",
        "🧮 Doku Analizi",
        "🔄 Çapraz-Doku Normalizasyonu",
        "📈 Doku Karşılaştırma",
        "🔬 Demo Analiz"
    ])
    
    with tab1:
        st.markdown("#### Doku-Spesifik Epigenetik Saat Kataloğu")
        
        clock_summary = get_tissue_clock_summary()
        st.dataframe(clock_summary, width='stretch')
        
        st.markdown("##### Desteklenen Dokular")
        
        tissue_info = [
            ("🧠 Beyin (Prefrontal Korteks)", "Bilişsel yaşlanma, nörodejenrasyon"),
            ("🧠 Beyin (Hipokampus)", "Hafıza, öğrenme fonksiyonları"),
            ("🧠 Beyin (Serebellum)", "Motor koordinasyon, denge"),
            ("🫀 Kalp", "Kardiyovasküler yaşlanma"),
            ("🫁 Akciğer", "Pulmoner yaşlanma"),
            ("🫘 Karaciğer", "Metabolik fonksiyon, detoksifikasyon"),
            ("🫘 Böbrek", "Renal fonksiyon"),
            ("💪 Kas", "Sarkopeni, fiziksel performans"),
            ("🩸 Kan", "Sistemik yaşlanma (altın standart)"),
            ("👅 Tükürük", "Non-invaziv örnekleme"),
            ("🧴 Cilt", "Dermatolojik yaşlanma"),
            ("🍖 Yağ Dokusu", "Metabolik sağlık")
        ]
        
        col1, col2 = st.columns(2)
        for i, (tissue, desc) in enumerate(tissue_info):
            with col1 if i % 2 == 0 else col2:
                st.markdown(f"**{tissue}**: {desc}")
    
    with tab2:
        st.markdown("#### Doku-Spesifik Yaş Analizi")
        
        col1, col2 = st.columns(2)
        with col1:
            tissue_type = st.selectbox(
                "Doku Tipi Seçin",
                [t.value for t in TissueType],
                format_func=lambda x: x.replace('_', ' ').title()
            )
            clock_type = st.radio("Saat Tipi", ["horvath", "hannum"])
        
        with col2:
            chron_age = st.number_input("Kronolojik Yaş", 20, 100, 45)
            n_cpgs = st.slider("Simüle CpG Sayısı", 100, 500, 300)
        
        if st.button("Doku Yaşı Hesapla", type="primary"):
            np.random.seed(42)
            simulated_methylation = np.random.beta(2, 5, n_cpgs)
            
            selected_tissue = TissueType(tissue_type)
            result = tissue_calc.calculate_tissue_age(
                simulated_methylation,
                chron_age,
                selected_tissue,
                clock_type
            )
            
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Epigenetik Yaş", f"{result.epigenetic_age:.1f} yıl")
            with col2:
                st.metric("EAA", f"{result.age_acceleration:+.1f} yıl")
            with col3:
                st.metric("Kalite Skoru", f"{result.quality_score:.2f}")
            with col4:
                st.metric("CpG Kapsama", f"{result.cpg_coverage:.1%}")
            
            st.markdown(f"**Yorum:** {result.interpretation}")
            
            if result.warning_flags:
                for warning in result.warning_flags:
                    st.warning(f"⚠️ {warning}")
            
            ref_info = tissue_calc.get_tissue_reference_percentile(
                result.age_acceleration, selected_tissue
            )
            st.info(f"Referans Persentil: %{ref_info['percentile']:.1f} | Kategori: {ref_info['category']}")
    
    with tab3:
        st.markdown("#### Çapraz-Doku Normalizasyon Faktörleri")
        
        norm_table = normalizer.get_normalization_table()
        st.dataframe(norm_table, width='stretch')
        
        st.markdown("##### Doku-Arası Dönüşüm")
        col1, col2, col3 = st.columns(3)
        with col1:
            source_tissue = st.selectbox(
                "Kaynak Doku",
                [t.value for t in TissueType],
                key="source_tissue",
                format_func=lambda x: x.replace('_', ' ').title()
            )
        with col2:
            target_tissue = st.selectbox(
                "Hedef Doku",
                [t.value for t in TissueType],
                key="target_tissue",
                format_func=lambda x: x.replace('_', ' ').title()
            )
        with col3:
            input_age = st.number_input("Kaynak Epigenetik Yaş", 20.0, 100.0, 55.0)
        
        if st.button("Dönüştür"):
            converted = normalizer.normalize_between_tissues(
                input_age,
                TissueType(source_tissue),
                TissueType(target_tissue)
            )
            st.success(f"**Dönüştürülmüş Yaş:** {converted:.1f} yıl")
    
    with tab4:
        st.markdown("#### Çoklu Doku Karşılaştırması")
        
        selected_tissues = st.multiselect(
            "Karşılaştırılacak Dokular",
            [t.value for t in TissueType],
            default=["blood", "brain_prefrontal_cortex", "liver"],
            format_func=lambda x: x.replace('_', ' ').title()
        )
        
        comparison_age = st.number_input("Kronolojik Yaş (Karşılaştırma)", 20, 100, 50)
        
        if st.button("Dokuları Karşılaştır") and selected_tissues:
            tissue_data = {}
            np.random.seed(42)
            
            for tissue in selected_tissues:
                tissue_data[TissueType(tissue)] = np.random.beta(2, 5, 300)
            
            comparison_df = tissue_calc.compare_tissues(
                tissue_data,
                comparison_age
            )
            st.dataframe(comparison_df, width='stretch')
            
            discordance = components['tissue_discordance']
            tissue_ages = {TissueType(t): np.random.normal(comparison_age + np.random.uniform(-5, 8), 2) 
                          for t in selected_tissues}
            
            analysis = discordance.analyze_discordance(tissue_ages, comparison_age)
            
            st.markdown("##### Uyumsuzluk Analizi")
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("CV", f"%{analysis['coefficient_of_variation']:.1f}")
            with col2:
                st.metric("Maks Fark", f"{analysis['max_discordance']:.1f} yıl")
            with col3:
                st.metric("Patern", analysis['pattern'])
            
            st.info(analysis['interpretation'])
    
    with tab5:
        st.markdown("#### Demo: Beyin Bölgeleri Karşılaştırması")
        
        demo_age = st.slider("Demo Kronolojik Yaş", 30, 80, 55)
        
        if st.button("Beyin Bölgeleri Analizi"):
            np.random.seed(int(demo_age))
            
            brain_results = []
            for tissue in [TissueType.BRAIN_PFC, TissueType.BRAIN_HIPPO, TissueType.BRAIN_CEREBELLUM]:
                meth_data = np.random.beta(2, 5, 350)
                result = tissue_calc.calculate_tissue_age(meth_data, demo_age, tissue)
                brain_results.append({
                    'Bölge': tissue.value.replace('brain_', '').replace('_', ' ').title(),
                    'Epigenetik Yaş': result.epigenetic_age,
                    'EAA': result.age_acceleration,
                    'Kalite': result.quality_score
                })
            
            brain_df = pd.DataFrame(brain_results)
            st.dataframe(brain_df, width='stretch')
            
            fastest = max(brain_results, key=lambda x: x['EAA'])
            slowest = min(brain_results, key=lambda x: x['EAA'])
            
            st.success(f"En hızlı yaşlanan: {fastest['Bölge']} (+{fastest['EAA']:.1f} yıl)")
            st.info(f"En yavaş yaşlanan: {slowest['Bölge']} ({slowest['EAA']:+.1f} yıl)")


def render_blockchain_audit(components):
    """Render Blockchain Audit Trail page"""
    
    st.markdown("### 🔐 Blockchain Denetim İzi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> Append-only hash-chain ledger ile adli zincir-of-custody takibi.
    SHA-256 kriptografik hash ile manipülasyon tespiti ve HMAC imza doğrulaması.
    </div>
    """, unsafe_allow_html=True)
    
    audit_ledger = components['audit_ledger']
    chain_of_custody = components['chain_of_custody']
    
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Zincir Durumu",
        "📝 Kayıt Ekle",
        "✅ Doğrulama",
        "⚖️ Delil Takibi",
        "🔬 Manipülasyon Testi"
    ])
    
    with tab1:
        st.markdown("#### Denetim Zinciri Özeti")
        
        summary = audit_ledger.get_chain_summary()
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Toplam Blok", summary.get('block_count', 0))
        with col2:
            st.metric("Durum", summary.get('status', 'bilinmiyor').title())
        with col3:
            genesis = summary.get('genesis_timestamp', '-')
            if genesis != '-':
                genesis = genesis[:10]
            st.metric("İlk Kayıt", genesis)
        with col4:
            latest = summary.get('latest_timestamp', '-')
            if latest != '-':
                latest = latest[:10]
            st.metric("Son Kayıt", latest)
        
        st.markdown("##### Zincir Parmak İzi")
        st.code(summary.get('chain_fingerprint', 'N/A'))
        
        st.markdown("##### Son Kayıtlar")
        audit_table = audit_ledger.get_audit_table(limit=20)
        st.dataframe(audit_table, width='stretch')
    
    with tab2:
        st.markdown("#### Yeni Denetim Kaydı Ekle")
        
        col1, col2 = st.columns(2)
        with col1:
            action_type = st.selectbox(
                "İşlem Tipi",
                [a.value for a in AuditAction],
                format_func=lambda x: x.replace('_', ' ').title()
            )
            actor_id = st.text_input("Aktör ID", value="user_001")
            actor_name = st.text_input("Aktör Adı", value="Dr. Araştırmacı")
        
        with col2:
            summary_text = st.text_area("İşlem Özeti", value="Epigenetik yaş analizi tamamlandı")
            sample_id = st.text_input("Örnek ID (opsiyonel)", value="SAMPLE_001")
        
        if st.button("Kayıt Ekle", type="primary"):
            block = audit_ledger.add_record(
                action=AuditAction(action_type),
                actor_id=actor_id,
                actor_name=actor_name,
                payload={'sample_id': sample_id, 'timestamp': datetime.now().isoformat()},
                summary=summary_text,
                metadata={'sample_id': sample_id}
            )
            st.success(f"✅ Kayıt eklendi! Blok Hash: {block.block_hash[:32]}...")
    
    with tab3:
        st.markdown("#### Zincir Bütünlüğü Doğrulama")
        
        if st.button("Zinciri Doğrula", type="primary"):
            validation = audit_ledger.validate_chain()
            
            if validation.is_valid:
                st.success(f"""
                ✅ **ZİNCİR GEÇERLİ**
                - Doğrulanan Blok: {validation.validated_blocks}/{validation.total_blocks}
                - Doğrulama Zamanı: {validation.validation_timestamp[:19]}
                - Zincir Hash: {validation.validation_hash[:32]}...
                """)
            else:
                st.error(f"""
                ❌ **MANİPÜLASYON TESPİT EDİLDİ**
                - İlk Geçersiz Blok: {validation.first_invalid_block}
                - Hata: {validation.error_message}
                - Doğrulanan: {validation.validated_blocks}/{validation.total_blocks}
                """)
        
        st.markdown("##### Daubert Kriterleri Uyumu")
        daubert_df = pd.DataFrame([
            {'Kriter': 'Test Edilebilirlik', 'Durum': '✅ Geçer', 'Açıklama': 'SHA-256 hash doğrulaması'},
            {'Kriter': 'Peer Review', 'Durum': '✅ Geçer', 'Açıklama': 'Açık kaynak algoritma'},
            {'Kriter': 'Hata Oranı', 'Durum': '✅ Geçer', 'Açıklama': '2^-256 çakışma olasılığı'},
            {'Kriter': 'Standartlar', 'Durum': '✅ Geçer', 'Açıklama': 'NIST SHA-256 standardı'},
            {'Kriter': 'Kabul', 'Durum': '✅ Geçer', 'Açıklama': 'Yaygın blockchain kullanımı'}
        ])
        st.dataframe(daubert_df, width='stretch')
    
    with tab4:
        st.markdown("#### Adli Delil Zincir-of-Custody")
        
        st.markdown("##### Yeni Delil Kaydet")
        col1, col2 = st.columns(2)
        with col1:
            evidence_id = st.text_input("Delil ID", value=f"EV-{datetime.now().strftime('%Y%m%d')}-001")
            evidence_type = st.selectbox("Delil Tipi", ["DNA Örneği", "Kan Örneği", "Doku Örneği", "Dijital Veri"])
            collector_name = st.text_input("Toplayıcı", value="Uzm. Adli Teknisyen")
        with col2:
            collection_location = st.text_input("Toplama Yeri", value="Olay Yeri A")
            collection_method = st.selectbox("Toplama Yöntemi", ["Swab", "Kan Alımı", "Biyopsi", "Dijital Kopya"])
            description = st.text_area("Açıklama", value="Olay yerinden alınan biyolojik örnek")
        
        if st.button("Delil Kaydet"):
            block_hash = chain_of_custody.register_evidence(
                evidence_id=evidence_id,
                evidence_type=evidence_type,
                collector_id="collector_001",
                collector_name=collector_name,
                collection_location=collection_location,
                collection_method=collection_method,
                description=description
            )
            st.success(f"✅ Delil kaydedildi! Hash: {block_hash[:32]}...")
        
        st.markdown("##### Delil Sorgula")
        query_evidence_id = st.text_input("Sorgulanacak Delil ID", key="query_ev")
        
        if st.button("Custody Chain Görüntüle") and query_evidence_id:
            custody_report = chain_of_custody.generate_custody_report(query_evidence_id)
            st.dataframe(custody_report, width='stretch')
    
    with tab5:
        st.markdown("#### Manipülasyon Tespit Demonstrasyonu")
        
        st.warning("⚠️ Bu demo, sistemin manipülasyonu nasıl tespit ettiğini gösterir. Gerçek veri etkilenmez.")
        
        simulator = TamperDetectionSimulator(audit_ledger)
        
        if st.button("Bütünlük Demo Çalıştır"):
            results = simulator.run_integrity_demo()
            
            for result in results:
                if result['result']:
                    st.success(f"✅ Adım {result['step']}: {result['description']} - {result['message']}")
                else:
                    st.error(f"❌ Adım {result['step']}: {result['description']} - {result['message']}")
        
        st.markdown("##### Nasıl Çalışır?")
        st.markdown("""
        1. **Hash Zinciri**: Her blok, önceki bloğun hash'ini içerir
        2. **Manipülasyon Tespiti**: Herhangi bir değişiklik hash uyumsuzluğuna yol açar
        3. **Dijital İmza**: HMAC-SHA256 ile blok doğrulaması
        4. **Append-Only**: Sadece yeni kayıt eklenebilir, mevcut kayıtlar değiştirilemez
        """)


def render_database_management(components):
    """Render Database Management page"""
    
    st.markdown("### 🗄️ Veritabanı Yönetimi")
    
    st.markdown("""
    <div class="info-box">
    <b>ℹ️ Bilgi:</b> PostgreSQL veritabanı kullanılarak hasta verileri, analiz sonuçları 
    ve tedavi önerileri kalıcı olarak saklanmaktadır.
    </div>
    """, unsafe_allow_html=True)
    
    db_manager = components['db_manager']
    
    try:
        is_connected = db_manager.is_connected()
        if is_connected:
            st.success("✅ Veritabanı bağlantısı aktif")
        else:
            st.warning("⚠️ Veritabanı bağlantısı kurulamadı. Demo modunda çalışıyor.")
    except Exception as e:
        st.warning(f"⚠️ Veritabanı bağlantı kontrolü başarısız. Demo modunda çalışıyor.")
        is_connected = False
    
    tab1, tab2, tab3, tab4 = st.tabs(["📊 İstatistikler", "👤 Hasta Yönetimi", "📈 Analizler", "🔄 Demo Veri"])
    
    with tab1:
        st.markdown("#### Veritabanı İstatistikleri")
        
        try:
            stats = db_manager.get_database_stats()
        except Exception as e:
            stats = {'connected': False, 'error': str(e)}
            st.warning("İstatistikler yüklenirken bir hata oluştu. Lütfen sayfayı yenileyin.")
        
        if stats.get('connected'):
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Toplam Hasta", stats.get('patient_count', 0))
            with col2:
                st.metric("Toplam Analiz", stats.get('analysis_count', 0))
            with col3:
                st.metric("Klinik Veri", stats.get('clinical_data_count', 0))
            with col4:
                st.metric("GSEA Sonucu", stats.get('gsea_result_count', 0))
            
            if stats.get('substance_counts'):
                st.markdown("##### Madde Tipine Göre Hasta Dağılımı")
                substance_df = pd.DataFrame([
                    {'Madde Tipi': k, 'Hasta Sayısı': v}
                    for k, v in stats['substance_counts'].items()
                ])
                st.dataframe(substance_df, width='stretch')
        else:
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Toplam Hasta", stats.get('patient_count', 0))
            with col2:
                st.metric("Toplam Analiz", stats.get('analysis_count', 0))
            with col3:
                st.metric("Klinik Veri", stats.get('clinical_data_count', 0))
            with col4:
                st.metric("GSEA Sonucu", stats.get('gsea_result_count', 0))
            
            if stats.get('error'):
                st.info(f"Veritabanı durumu: {stats.get('error')}")
    
    with tab2:
        st.markdown("#### Hasta Kayıt ve Yönetimi")
        
        with st.expander("Yeni Hasta Ekle"):
            patient_id = st.text_input("Hasta ID", "PATIENT001")
            sex = st.selectbox("Cinsiyet", ["male", "female"])
            substance_type = st.selectbox(
                "Madde Tipi",
                ["control", "alcohol", "cocaine", "opioids", "methamphetamine", "cannabis", "polysubstance"]
            )
            smoking = st.number_input("Sigara (paket-yıl)", 0.0, 100.0, 0.0)
            bmi = st.number_input("BMI", 15.0, 50.0, 25.0)
            notes = st.text_area("Notlar")
            
            if st.button("Hasta Kaydet"):
                try:
                    patient = db_manager.create_patient({
                        'patient_id': patient_id,
                        'sex': sex,
                        'substance_type': substance_type,
                        'smoking_pack_years': smoking,
                        'bmi': bmi,
                        'notes': notes
                    })
                    
                    if patient:
                        st.success(f"✅ Hasta {patient_id} başarıyla kaydedildi!")
                    else:
                        st.error("Hasta kaydedilemedi")
                except Exception as e:
                    st.error(f"Hata: {str(e)}")
        
        st.markdown("##### Kayıtlı Hastalar")
        try:
            patients = db_manager.get_all_patients()
        except Exception as e:
            patients = []
            st.warning("Hasta listesi yüklenirken hata oluştu.")
        
        if patients:
            patient_df = pd.DataFrame([
                {
                    'ID': p.patient_id,
                    'Cinsiyet': p.sex,
                    'Madde Tipi': p.substance_type,
                    'Oluşturulma': p.created_at.strftime('%d.%m.%Y') if p.created_at else '-'
                }
                for p in patients[:20]
            ])
            st.dataframe(patient_df, width='stretch')
        else:
            st.info("Henüz kayıtlı hasta yok")
    
    with tab3:
        st.markdown("#### Analiz Geçmişi")
        
        try:
            patients_for_analysis = db_manager.get_all_patients()
        except Exception:
            patients_for_analysis = []
        
        if patients_for_analysis:
            selected_patient = st.selectbox(
                "Hasta Seç",
                [p.patient_id for p in patients_for_analysis]
            )
            
            if selected_patient:
                try:
                    analyses = db_manager.get_patient_analyses(selected_patient)
                except Exception:
                    analyses = []
                    st.warning("Analizler yüklenirken hata oluştu.")
                
                if analyses:
                    analysis_df = pd.DataFrame([
                        {
                            'Tarih': a.analysis_date.strftime('%d.%m.%Y') if a.analysis_date else '-',
                            'Kronolojik Yaş': a.chronological_age,
                            'GrimAge EAA': a.grimage_eaa,
                            'Risk Kategorisi': a.risk_category
                        }
                        for a in analyses
                    ])
                    st.dataframe(analysis_df, width='stretch')
                else:
                    st.info("Bu hasta için analiz kaydı yok")
        else:
            st.info("Önce hasta kaydı oluşturun")
    
    with tab4:
        st.markdown("#### Demo Veri Oluştur")
        
        n_demo_patients = st.slider("Demo Hasta Sayısı", 5, 50, 10)
        
        if st.button("Demo Verileri Oluştur"):
            with st.spinner("Demo veriler oluşturuluyor..."):
                np.random.seed(42)
                
                substances = ["control", "alcohol", "cocaine", "opioids"]
                sexes = ["male", "female"]
                
                created = 0
                for i in range(n_demo_patients):
                    try:
                        patient = db_manager.create_patient({
                            'patient_id': f"DEMO{str(i+1).zfill(4)}",
                            'sex': np.random.choice(sexes),
                            'substance_type': np.random.choice(substances),
                            'smoking_pack_years': np.random.uniform(0, 30),
                            'bmi': np.random.uniform(18, 35),
                            'notes': 'Demo veri'
                        })
                        if patient:
                            created += 1
                    except Exception:
                        pass
                
                st.success(f"✅ {created} demo hasta oluşturuldu!")
                st.rerun()


if __name__ == "__main__":
    main()
